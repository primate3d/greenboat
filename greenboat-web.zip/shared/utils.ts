/**
 * Générer un numéro de devis au format GB-YYYY-XXXXX
 * GB = Green Boat
 * YYYY = Année actuelle
 * XXXXX = Numéro aléatoire 5 chiffres
 */
export function generateQuoteNumber(): string {
  const year = new Date().getFullYear();
  const randomNumber = Math.floor(Math.random() * 100000)
    .toString()
    .padStart(5, "0");
  return `GB-${year}-${randomNumber}`;
}

/**
 * Calculer le prix total basé sur la surface du bateau
 * Formule : surface * 15€ par m²
 * Les prix sont en centimes d'euros
 */
export function calculateTotalPrice(
  basePrice: number,
  boatLength: number,
  surface: number
): number {
  // surface est en m² * 100 (ex: 2500 = 25m²)
  const surfaceInSquareMeters = surface / 100;

  // Calcul du prix : 15€ par m² = 1500 centimes
  const totalPrice = surfaceInSquareMeters * 1500; // 15€ par m² = 1500 centimes

  return Math.round(totalPrice);
}

/**
 * Formater un prix en centimes vers une chaîne de caractères EUR
 */
export function formatPrice(priceInCents: number): string {
  const euros = (priceInCents / 100).toFixed(2);
  return `${euros}€`;
}

/**
 * Formater une date au format français
 */
export function formatDateFR(date: Date): string {
  return date.toLocaleDateString("fr-FR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/**
 * Obtenir le jour de la semaine (0-6) pour une date
 */
export function getDayOfWeek(date: Date): number {
  return date.getDay();
}

/**
 * Formater l'heure au format HH:MM
 */
export function formatTime(hours: number, minutes: number): string {
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

/**
 * Convertir une chaîne HH:MM en minutes depuis minuit
 */
export function timeToMinutes(timeStr: string): number {
  const [hours, minutes] = timeStr.split(":").map(Number);
  return hours * 60 + minutes;
}

/**
 * Convertir les minutes depuis minuit en chaîne HH:MM
 */
export function minutesToTime(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return formatTime(hours, mins);
}
