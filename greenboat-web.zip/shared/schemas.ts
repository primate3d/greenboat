import { z } from "zod";

/**
 * Schéma de validation pour les informations client
 */
export const clientInfoSchema = z.object({
  name: z.string().min(1, "Le nom est requis").trim(),
  email: z.string().email("Veuillez entrer une adresse email valide").toLowerCase(),
  phone: z
    .string()
    .regex(
      /^(?:0|\+33)[1-9](?:[0-9]{8})$/,
      "Veuillez entrer un numéro de téléphone français valide (06/07...)"
    ),
});

export type ClientInfo = z.infer<typeof clientInfoSchema>;

/**
 * Schéma de validation pour les informations du bateau
 */
export const boatInfoSchema = z.object({
  name: z.string().optional().default(""),
  brand: z.string().optional().default(""), // Marque du bateau
  model: z.string().optional().default(""), // Modèle du bateau
  category: z.enum(["voilier", "moteur", "autre"], { message: "Veuillez sélectionner une catégorie" }),
  length: z
    .number()
    .min(2, "La longueur doit être au moins 2 mètres")
    .max(100, "La longueur ne doit pas dépasser 100 mètres"),
  lengthAtWaterline: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 2 && val <= 100), "La longueur à la flottaison doit être entre 2 et 100 mètres"),
  width: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 0.5 && val <= 50), "La largeur doit être entre 0.5 et 50 mètres"),
  draft: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 0.1 && val <= 10), "Le tirant d'eau doit être entre 0.1 et 10 mètres"),
  surface: z
    .number()
    .min(1, "La surface doit être au moins 1 m²")
    .max(500, "La surface ne doit pas dépasser 500 m²"),
  portAddress: z.string().min(3, "Veuillez entrer une adresse valide"),
  quai: z.string().min(1, "Veuillez entrer le quai"),
  emplacement: z.string().min(1, "Veuillez entrer l'emplacement du bateau"),
});

export type BoatInfo = z.infer<typeof boatInfoSchema>;

/**
 * Schéma de validation pour la sélection de date et zone
 */
export const dateZoneSchema = z.object({
  zoneId: z.number().int().positive("Veuillez sélectionner une zone"),
  reservationDate: z.date().refine(
    (date) => date > new Date(),
    "La date doit être dans le futur"
  ),
});

export type DateZoneInfo = z.infer<typeof dateZoneSchema>;

/**
 * Schéma de validation pour la sélection d'horaire
 */
export const timeSlotSchema = z.object({
  startTime: z.string().regex(/^\d{2}:\d{2}$/, "Format d'heure invalide"),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, "Format d'heure invalide"),
});

export type TimeSlotInfo = z.infer<typeof timeSlotSchema>;

/**
 * Schéma complet de réservation
 */
export const bookingSchema = z.object({
  clientName: z.string().min(1, "Le nom est requis").trim(),
  clientEmail: z.string().email("Veuillez entrer une adresse email valide").toLowerCase(),
  clientPhone: z
    .string()
    .regex(
      /^(?:0|\+33)[1-9](?:[0-9]{8})$/,
      "Veuillez entrer un numéro de téléphone français valide (06/07...)"
    ),
  boatName: z.string().optional().default(""),
  boatBrand: z.string().optional().default(""), // Marque du bateau
  boatModel: z.string().optional().default(""), // Modèle du bateau
  boatCategory: z.enum(["voilier", "moteur", "autre"], { message: "Veuillez sélectionner une catégorie" }),
  boatLength: z
    .number()
    .min(2, "La longueur doit être au moins 2 mètres")
    .max(100, "La longueur ne doit pas dépasser 100 mètres"),
  boatLengthAtWaterline: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 2 && val <= 100), "La longueur à la flottaison doit être entre 2 et 100 mètres"),
  boatWidth: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 0.5 && val <= 50), "La largeur doit être entre 0.5 et 50 mètres"),
  boatDraft: z
    .number()
    .optional()
    .refine((val) => !val || (val >= 0.1 && val <= 10), "Le tirant d'eau doit être entre 0.1 et 10 mètres"),
  surface: z
    .number()
    .min(1, "La surface doit être au moins 1 m²")
    .max(500, "La surface ne doit pas dépasser 500 m²"),
  portAddress: z.string().min(3, "Veuillez entrer une adresse valide"),
  quai: z.string().min(1, "Veuillez entrer le quai"),
  emplacement: z.string().min(1, "Veuillez entrer l'emplacement du bateau"),
  zoneId: z.number().int().positive("Veuillez sélectionner une zone"),
  reservationDate: z.date(),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, "Format d'heure invalide"),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, "Format d'heure invalide"),
});

export type BookingData = z.infer<typeof bookingSchema>;
