ALTER TABLE `reservations` MODIFY COLUMN `notes` text;
