import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Zones de service avec tarification de base
 */
export const zones = mysqlTable("zones", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  basePrice: int("basePrice").notNull(), // Prix en centimes d'euros
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Zone = typeof zones.$inferSelect;
export type InsertZone = typeof zones.$inferInsert;

/**
 * Créneaux horaires disponibles par zone
 */
export const availableTimeSlots = mysqlTable("availableTimeSlots", {
  id: int("id").autoincrement().primaryKey(),
  zoneId: int("zoneId").notNull(),
  dayOfWeek: int("dayOfWeek").notNull(), // 0-6 (dimanche-samedi)
  startTime: varchar("startTime", { length: 5 }).notNull(), // HH:MM
  endTime: varchar("endTime", { length: 5 }).notNull(), // HH:MM
  maxReservations: int("maxReservations").default(5).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AvailableTimeSlot = typeof availableTimeSlots.$inferSelect;
export type InsertAvailableTimeSlot = typeof availableTimeSlots.$inferInsert;

/**
 * Réservations de nettoyage de carènes
 */
export const reservations = mysqlTable("reservations", {
  id: int("id").autoincrement().primaryKey(),
  quoteNumber: varchar("quoteNumber", { length: 20 }).notNull().unique(), // GB-YYYY-XXXXX

  // Informations client
  clientName: varchar("clientName", { length: 100 }).notNull(),
  clientEmail: varchar("clientEmail", { length: 320 }).notNull(),
  clientPhone: varchar("clientPhone", { length: 20 }).notNull(),

  // Informations bateau
  boatName: varchar("boatName", { length: 100 }),
  boatBrand: varchar("boatBrand", { length: 100 }), // Marque du bateau (ex: Bénéteau)
  boatModel: varchar("boatModel", { length: 100 }), // Modèle du bateau (ex: Oceanis 38)
  boatCategory: mysqlEnum("boatCategory", ["voilier", "moteur", "autre"]).notNull(),
  boatLength: int("boatLength").notNull(), // Longueur hors tout en décimètres (ex: 95 = 9.5m)
  boatLengthAtWaterline: int("boatLengthAtWaterline"), // Longueur à la flottaison en décimètres (optionnel)
  boatWidth: int("boatWidth"), // Largeur en décimètres (optionnel)
  boatDraft: int("boatDraft"), // Tirant d'eau en décimètres (ex: 20 = 2.0m)
  surface: int("surface").notNull(), // Surface immergée en m² * 100 (ex: 2500 = 25m²)
  portAddress: varchar("portAddress", { length: 255 }).notNull(),
  quai: varchar("quai", { length: 100 }).notNull(),
  emplacement: varchar("emplacement", { length: 255 }).notNull(),

  // Réservation
  zoneId: int("zoneId").notNull(),
  reservationDate: timestamp("reservationDate").notNull(),
  startTime: varchar("startTime", { length: 5 }).notNull(),
  endTime: varchar("endTime", { length: 5 }).notNull(),

  // Tarification
  basePrice: int("basePrice").notNull(), // Prix de base en centimes
  totalPrice: int("totalPrice").notNull(), // Prix total en centimes

  // Statut
  status: mysqlEnum("status", ["pending", "confirmed", "completed", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),

  // Audit
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = typeof reservations.$inferInsert;

/**
 * Modèles de bateaux avec spécifications techniques
 */
export const boatModels = mysqlTable("boatModels", {
  id: int("id").autoincrement().primaryKey(),
  brand: varchar("brand", { length: 100 }).notNull(), // Marque (ex: Beneteau)
  model: varchar("model", { length: 500 }).notNull(), // Modèle (ex: Oceanis 411)
  loa: decimal("loa", { precision: 5, scale: 2 }).notNull(), // Longueur hors tout en mètres
  beam: decimal("beam", { precision: 5, scale: 2 }).notNull(), // Largeur en mètres
  draft: decimal("draft", { precision: 5, scale: 2 }).notNull(), // Tirant d'eau en mètres
  surface: decimal("surface", { precision: 8, scale: 2 }).notNull(), // Surface immergée en m²
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BoatModel = typeof boatModels.$inferSelect;
export type InsertBoatModel = typeof boatModels.$inferInsert;
