ALTER TABLE `reservations` ADD `boatBrand` varchar(100);--> statement-breakpoint
ALTER TABLE `reservations` ADD `boatModel` varchar(100);--> statement-breakpoint
ALTER TABLE `reservations` ADD `boatLengthAtWaterline` int;--> statement-breakpoint
ALTER TABLE `reservations` ADD `boatWidth` int;--> statement-breakpoint
ALTER TABLE `reservations` ADD `boatDraft` int;