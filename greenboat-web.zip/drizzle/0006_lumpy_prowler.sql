CREATE TABLE `boatModels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`brand` varchar(100) NOT NULL,
	`model` varchar(100) NOT NULL,
	`loa` decimal(5,2) NOT NULL,
	`beam` decimal(5,2) NOT NULL,
	`draft` decimal(5,2) NOT NULL,
	`surface` decimal(8,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `boatModels_id` PRIMARY KEY(`id`)
);
