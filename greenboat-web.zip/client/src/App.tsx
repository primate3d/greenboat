import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import AdminReservations from "./pages/AdminReservations";
import { ArcachonPage, HossegorPage, SaintJeanDeLuzPage } from "./pages/CityPages";
import Blog from "./pages/Blog";
import MentionsLegales from "./pages/MentionsLegales";
import ValidateReservation from "./pages/ValidateReservation";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/villes/arcachon-nettoyage-bateau" component={ArcachonPage} />
      <Route path="/villes/hossegor-nettoyage-bateau" component={HossegorPage} />
      <Route path="/villes/saint-jean-de-luz-nettoyage-bateau" component={SaintJeanDeLuzPage} />
      <Route path="/blog/nettoyage-bateau-quai-hiver-nouvelle-aquitaine" component={Blog} />
      <Route path="/mentions-legales" component={MentionsLegales} />
      <Route path="/validate-reservation" component={ValidateReservation} />
      <Route path="/admin/reservations" component={AdminReservations} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
