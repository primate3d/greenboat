import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { SEOSchema, BreadcrumbSchema } from "@/components/SEOSchema";

interface CityPageProps {
  city: "arcachon" | "hossegor" | "saint-jean-de-luz";
}

const cityData = {
  arcachon: {
    title: "Nettoyage Bateau à Quai à Arcachon | Green Boat",
    description:
      "Service professionnel de nettoyage bateau à quai à Arcachon. Intervention directe ponton, coque, pont, cabine. Devis gratuit.",
    h1: "Nettoyage Bateau à Quai à Arcachon - Intervention Directe Ponton",
    cityName: "Arcachon",
    region: "Gironde (33)",
    zones: [
      "Arcachon centre",
      "La Teste-de-Buch",
      "Cap-Ferret",
      "Gujan-Mestras",
      "Arès",
      "Andernos-les-Bains",
    ],
    intro: `Arcachon, perle du bassin d'Arcachon, accueille des centaines de propriétaires de bateaux qui font face aux défis du climat maritime : sel, humidité, algues et dépôts organiques qui ternissent les coques. Green Boat propose un service professionnel de nettoyage bateau à quai avec intervention directe ponton, sans besoin de sortir votre bateau de l'eau.`,
    content: `Nos équipes interviennent sur tous les types de bateaux : voiliers, moteurs, bateaux de pêche et yachts. Nous nettoyons la coque, le pont, la cabine, et proposons des services spécialisés comme l'antifouling et le cirage gelcoat. Nos techniques écologiques respectent l'environnement fragile du bassin d'Arcachon et ses écosystèmes ostréicoles.

À Arcachon, nous intervenons sur les pontons de La Teste, Cap-Ferret, Gujan-Mestras et Arcachon centre. Nos interventions sont rapides (2 heures en moyenne) et programmées selon votre disponibilité. Vous restez à bord ou profitez d'une pause café pendant que nous travaillons.`,
    services: [
      "Nettoyage coque (sel, algues, dépôts calcaires)",
      "Antifouling et protection coque",
      "Nettoyage pont et cabine",
      "Cirage gelcoat haute brillance",
      "Inspection et maintenance",
    ],
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/MnVPGllwfawHUrFe.jpg",
  },
  hossegor: {
    title: "Nettoyage Bateau à Quai Hossegor | Green Boat",
    description:
      "Nettoyage bateau à quai à Hossegor et Landes. Intervention directe ponton, coque, pont. Service écologique. Devis gratuit.",
    h1: "Nettoyage Bateau à Quai à Hossegor - Intervention Directe Ponton",
    cityName: "Hossegor",
    region: "Landes (40)",
    zones: [
      "Hossegor",
      "Capbreton",
      "Seignosse",
      "Mimizan",
      "Moliets",
      "Messanges",
    ],
    intro: `Hossegor, capitale du surf français, accueille aussi une communauté importante de propriétaires de bateaux. Entre les vagues de l'Atlantique et les marées du lac marin, vos bateaux subissent des conditions extrêmes : sel, sable, algues brunes et dépôts calcaires. Green Boat propose un nettoyage bateau à quai professionnel avec intervention directe ponton à Hossegor.`,
    content: `Nos équipes interviennent sur les pontons d'Hossegor, Capbreton, Seignosse et Mimizan. Nous nettoyons tous les types de bateaux : voiliers de loisir, bateaux de pêche côtière, moteurs de croisière. Nos services incluent le nettoyage coque (antifouling compris), pont, cabine, et cirage gelcoat haute brillance.

À Hossegor, nous comprenons les besoins spécifiques des propriétaires : interventions rapides, respect des horaires de marée, et techniques écologiques. Nos produits ne polluent pas le lac marin et respectent la biodiversité locale. Intervention en 2 heures, tarification transparente, devis gratuit.`,
    services: [
      "Nettoyage coque (sel, algues brunes, dépôts calcaires)",
      "Antifouling spécialisé lac marin",
      "Nettoyage pont et cabine",
      "Cirage gelcoat protection UV",
      "Respect horaires marée",
    ],
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/WRNhamzbFdjlPVZT.jpg",
  },
  "saint-jean-de-luz": {
    title: "Nettoyage Bateau à Quai Saint-Jean-de-Luz | Green Boat",
    description:
      "Nettoyage bateau à quai à Saint-Jean-de-Luz, Pays Basque. Intervention directe ponton, coque, pont, cabine. Écologique.",
    h1: "Nettoyage Bateau à Quai à Saint-Jean-de-Luz - Intervention Directe Ponton",
    cityName: "Saint-Jean-de-Luz",
    region: "Pays Basque (64)",
    zones: [
      "Saint-Jean-de-Luz",
      "Hendaye",
      "Ciboure",
      "Socoa",
      "Urrugne",
    ],
    intro: `Saint-Jean-de-Luz, port historique du Pays Basque, accueille des centaines de bateaux de pêche, voiliers et yachts. Entre l'océan Atlantique et les marées côtières, vos bateaux accumulent sel, algues rouges et dépôts organiques. Green Boat propose un nettoyage bateau à quai professionnel avec intervention directe ponton à Saint-Jean-de-Luz.`,
    content: `Nos équipes interviennent sur les pontons de Saint-Jean-de-Luz, Hendaye et Ciboure. Nous nettoyons tous les types de bateaux : chalutiers, voiliers, bateaux de loisir, yachts. Nos services incluent le nettoyage coque (antifouling), pont, cabine, et cirage gelcoat. Nous proposons aussi des services spécialisés pour les bateaux de pêche professionnels.

À Saint-Jean-de-Luz, nous respectons les traditions maritimes basques et les besoins spécifiques des pêcheurs. Nos interventions sont rapides (2 heures), programmées selon les horaires de marée, et utilisent des techniques écologiques. Tarification transparente, devis gratuit, intervention à quai sans sortie bateau.`,
    services: [
      "Nettoyage coque (sel, algues rouges, dépôts organiques)",
      "Antifouling bateau pêche professionnelle",
      "Nettoyage pont et cabine",
      "Cirage gelcoat protection marine",
      "Services spécialisés chalutiers",
    ],
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/jeOnPCISDrywvgIN.jpg",
  },
};

export function CityPage({ city }: CityPageProps) {
  const [, setLocation] = useLocation();
  const data = cityData[city];
  
  useEffect(() => {
    document.title = data.title;
  }, [data.title]);

  const breadcrumbItems = [
    { name: "Accueil", url: "https://greenboat.fr" },
    { name: "Villes", url: "https://greenboat.fr/villes" },
    { name: data.cityName, url: `https://greenboat.fr/villes/${city}-nettoyage-bateau` },
  ];

  return (
    <>
      <SEOSchema city={city} />
      <BreadcrumbSchema items={breadcrumbItems} />
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1
            className="text-2xl font-bold text-blue-600 cursor-pointer"
            onClick={() => setLocation("/")}
          >
            Green Boat
          </h1>
          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={() => setLocation("/services")}
            >
              Services
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/contact")}
            >
              Contact
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-50 to-indigo-50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {data.h1}
          </h1>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl">
            {data.intro}
          </p>
          <Button
            size="lg"
            onClick={() => setLocation("/booking")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Réserver maintenant
          </Button>
        </div>
      </section>

      {/* Image Section */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-4">
          <img
            src={data.image}
            alt={`Nettoyage bateau à quai à ${data.cityName} - Green Boat`}
            className="w-full h-96 object-cover rounded-lg shadow-lg"
          />
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="md:col-span-2">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Pourquoi faire nettoyer son bateau à {data.cityName} ?
              </h2>
              <p className="text-gray-700 mb-6 leading-relaxed">
                {data.content}
              </p>

              <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
                Services de nettoyage bateau à quai à {data.cityName}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {data.services.map((service, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-4 bg-white rounded-lg border border-gray-200"
                  >
                    <div className="text-blue-600 font-bold text-xl mt-1">
                      ✓
                    </div>
                    <p className="text-gray-700">{service}</p>
                  </div>
                ))}
              </div>

              <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
                Zones d'intervention à {data.cityName}
              </h2>
              <p className="text-gray-700 mb-4">
                Nous intervenons sur les pontons suivants :
              </p>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {data.zones.map((zone, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <span className="text-blue-600">•</span>
                    <span className="text-gray-700">{zone}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Sidebar */}
            <div className="bg-white p-8 rounded-lg shadow-lg h-fit sticky top-4">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Réservez maintenant
              </h3>
              <p className="text-gray-700 mb-6">
                Service professionnel de nettoyage bateau à quai à{" "}
                <strong>{data.cityName}</strong>, {data.region}.
              </p>
              <Button
                size="lg"
                onClick={() => setLocation("/booking")}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white mb-4"
              >
                Réserver
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setLocation("/contact")}
                className="w-full"
              >
                Demander un devis
              </Button>

              <div className="mt-8 pt-8 border-t">
                <h4 className="font-bold text-gray-900 mb-4">
                  Pourquoi Green Boat ?
                </h4>
                <ul className="space-y-3 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>Intervention directe ponton</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>Techniques écologiques</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>Tarification transparente</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>Intervention rapide (2h)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 font-bold">✓</span>
                    <span>Devis gratuit</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="bg-blue-600 text-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-3xl font-bold">150+</p>
              <p className="text-sm mt-2">Bateaux nettoyés</p>
            </div>
            <div>
              <p className="text-3xl font-bold">98%</p>
              <p className="text-sm mt-2">Clients satisfaits</p>
            </div>
            <div>
              <p className="text-3xl font-bold">5★</p>
              <p className="text-sm mt-2">Note moyenne</p>
            </div>
            <div>
              <p className="text-3xl font-bold">100%</p>
              <p className="text-sm mt-2">Écologique</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Prêt à réserver ?
          </h2>
          <p className="text-xl text-gray-700 mb-8">
            Commencez votre réservation en quelques minutes
          </p>
          <Button
            size="lg"
            onClick={() => setLocation("/booking")}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Réserver maintenant
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p>
            &copy; 2026 Green Boat - Nettoyage Bateau à Quai. Tous droits
            réservés.
          </p>
          <p className="mt-2 text-gray-400">
            Intervention directe ponton | Écologique | Nouvelle-Aquitaine
          </p>
        </div>
      </footer>
    </div>
    </>
  );
}

// Export individual pages
export function ArcachonPage() {
  return <CityPage city="arcachon" />;
}

export function HossegorPage() {
  return <CityPage city="hossegor" />;
}

export function SaintJeanDeLuzPage() {
  return <CityPage city="saint-jean-de-luz" />;
}
