import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ReservationModal } from "@/components/ReservationModal";


const HERO_IMAGE = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/BNNkMvIAtGTaFCvD.png";
const KEELCRAB_IMAGE = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/IBpWZFqZxxfVLRwP.png";

export default function Home() {
  const [isReservationOpen, setIsReservationOpen] = useState(false);

  return (
    <div className="w-full bg-white">
      {/* Header Navigation */}
      <header className="sticky top-0 z-50 bg-gradient-to-r from-green-600 to-blue-600 shadow-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-2xl">⛵</div>
            <div>
              <h1 className="text-white font-bold text-xl">Green boat</h1>
              <p className="text-white text-xs">Nettoyage Écologique de Carènes</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="#about" className="text-white hover:text-gray-100 transition">À propos</a>
            <a href="#services" className="text-white hover:text-gray-100 transition">Services</a>
            <a href="#contact" className="text-white hover:text-gray-100 transition">Contact</a>
            <Button 
              onClick={() => setIsReservationOpen(true)}
              className="bg-white text-green-600 hover:bg-gray-100 font-semibold"
            >
              Réserver
            </Button>
          </nav>
          <div className="hidden md:block text-white text-sm bg-blue-700 bg-opacity-30 px-4 py-2 rounded-full">
            🍃 Protégeons notre environnement
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen bg-gradient-to-r from-green-600 via-teal-500 to-blue-600 overflow-hidden">
        <img 
          src={HERO_IMAGE}
          alt="Bateau nettoyage écologique"
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="relative z-10 container mx-auto px-4 h-full flex flex-col items-center justify-center text-center">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 max-w-3xl">
            L'Entretien Professionnel<br />de Votre Bateau
          </h2>
          <div className="w-24 h-1 bg-green-300 mx-auto mb-8"></div>
          <p className="text-xl text-white mb-8 max-w-2xl">
            Nettoyage sous-marin à quai utilisant la technologie Keelcrab pour éliminer <span className="text-green-200 font-semibold">algues, balanes et organismes marins</span> sans sortir votre bateau de l'eau
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-4xl w-full">
            <div className="bg-white bg-opacity-10 border border-white border-opacity-20 rounded-xl p-6 backdrop-blur">
              <div className="text-4xl mb-3">☎️</div>
              <h3 className="font-bold mb-2 text-2xl" style={{color: "#0fb812"}}>RÉSERVEZ</h3>
              <p className="text-white text-sm">En quelques clics</p>
            </div>
            <div className="bg-white bg-opacity-10 border border-white border-opacity-20 rounded-xl p-6 backdrop-blur">
              <div className="text-4xl mb-3">🧹</div>
              <h3 className="font-bold mb-2 text-2xl" style={{color: "#1bb61e"}}>NETTOYER</h3>
              <p className="text-white text-sm">Nous intervenons à quai</p>
            </div>
            <div className="bg-white bg-opacity-10 border border-white border-opacity-20 rounded-xl p-6 backdrop-blur">
              <div className="text-4xl mb-3">🚤</div>
              <h3 className="font-bold mb-2 text-2xl" style={{color: "#24cc56"}}>NAVIGUEZ</h3>
              <p className="text-white text-sm">En toute confiance</p>
            </div>
          </div>
          <Button 
            onClick={() => setIsReservationOpen(true)}
            className="bg-gradient-to-r from-green-500 to-teal-500 text-white px-8 py-3 text-lg hover:opacity-90 transition"
          >
            Technologie Keelcrab - Professional & Écologique
          </Button>
        </div>
      </section>

      {/* Problem Section */}
      <section id="about" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-white border-l-4 border-orange-500 rounded-xl p-8 mb-12 shadow-lg">
            <div className="flex gap-4 mb-4">
              <div className="text-4xl">⚠️</div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Le problème : l'encrassement marin</h3>
                <p className="text-gray-700 mb-4">
                  Au fil du temps, <span className="text-orange-600 font-semibold">algues, coquillages et organismes marins</span> se fixent sur la carène, causant :
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex gap-2">
                    <span className="text-orange-600">📉</span>
                    <span>Perte de vitesse jusqu'à 30%</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-orange-600">⛽</span>
                    <span>+20 à 40% de carburant</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-orange-600">🎨</span>
                    <span>Détérioration de la peinture</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-orange-600">🐚</span>
                    <span>Espèces invasives</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <h3 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-2">
            <span className="text-green-600">✓</span> Les avantages du nettoyage régulier
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border-t-4 border-t-blue-500 p-6 text-center">
              <div className="text-4xl mb-4">✏️</div>
              <h4 className="font-bold text-lg mb-2">Performances</h4>
              <p className="text-sm text-gray-600">Réduit la traînée hydraulique et restaure la vitesse</p>
            </Card>
            <Card className="border-t-4 border-t-green-500 p-6 text-center">
              <div className="text-4xl mb-4">⛽</div>
              <h4 className="font-bold text-lg mb-2">Économies</h4>
              <p className="text-sm text-gray-600">Réduisez la consommation de 20 à 40%</p>
            </Card>
            <Card className="border-t-4 border-t-cyan-500 p-6 text-center">
              <div className="text-4xl mb-4">🛡️</div>
              <h4 className="font-bold text-lg mb-2">Protection</h4>
              <p className="text-sm text-gray-600">Préserve l'efficacité de la peinture antifouling</p>
            </Card>
            <Card className="border-t-4 border-t-green-400 p-6 text-center">
              <div className="text-4xl mb-4">🌿</div>
              <h4 className="font-bold text-lg mb-2">Écologie</h4>
              <p className="text-sm text-gray-600">Évitez la propagation d'espèces invasives</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section id="services" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src={KEELCRAB_IMAGE}
                alt="Robot Keelcrab"
                className="rounded-2xl shadow-xl"
              />
              <div className="mt-6 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-full py-3 px-6 text-center font-semibold">
                Technologie Keelcrab
              </div>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-8">Comment ça marche ?</h3>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="bg-orange-100 rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">ℹ️</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Comment ça marche ?</h4>
                    <p className="text-gray-600">Le robot Keelcrab nettoie la carène <span className="text-orange-600 font-semibold">sans sortir le bateau de l'eau</span>, éliminant algues, moules, balanes et tous les organismes marins incrustés</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📡</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Contrôle à distance</h4>
                    <p className="text-gray-600">Pilotage intuitif depuis le quai avec caméra en direct pour une précision optimale</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🔄</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Brosses rotatives professionnelles</h4>
                    <p className="text-gray-600">Système rotatif puissant qui retire les incrustations sans endommager la peinture</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="bg-teal-100 rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">⏱️</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Nettoyage rapide et efficace</h4>
                    <p className="text-gray-600">Intervention complète en 1 à 2 heures selon la taille du bateau</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🌿</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Zéro produits chimiques</h4>
                    <p className="text-gray-600">Nettoyage mécanique 100% écologique qui respecte l'écosystème marin</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-blue-100 border-l-4 border-blue-600 rounded-xl p-6 mb-12">
            <div className="flex gap-3 items-start">
              <span className="text-2xl">📏</span>
              <div>
                <h4 className="font-bold text-gray-900 mb-2">Calcul de la surface immergée</h4>
                <p className="text-gray-700">Voilier/Moteur : Longueur × 1,5 m | Catamaran : Longueur × 2,2 m</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="border-t-4 border-t-green-500 p-6">
              <div className="text-center mb-6">
                <div className="text-green-600 text-3xl mb-2">✓</div>
                <h4 className="font-bold text-xl mb-2">STANDARD</h4>
                <p className="text-gray-600 text-sm">Entretien régulier</p>
              </div>
              <div className="space-y-3 text-sm">
                <div>Voilier: <span className="text-green-600 font-bold">8 €/m²</span></div>
                <div>Moteur: <span className="text-green-600 font-bold">9 €/m²</span></div>
                <div>Catamaran: <span className="text-green-600 font-bold">10 €/m²</span></div>
              </div>
            </Card>

            <Card className="border-t-4 border-t-orange-500 p-6">
              <div className="text-center mb-6">
                <div className="text-orange-600 text-3xl mb-2">⚠️</div>
                <h4 className="font-bold text-xl mb-2">RENFORCÉ</h4>
                <p className="text-gray-600 text-sm">Encrassement important</p>
              </div>
              <div className="space-y-3 text-sm">
                <div>Voilier: <span className="text-orange-600 font-bold">12 €/m²</span></div>
                <div>Moteur: <span className="text-orange-600 font-bold">13 €/m²</span></div>
                <div>Catamaran: <span className="text-orange-600 font-bold">14 €/m²</span></div>
              </div>
            </Card>

            <Card className="border-t-4 border-t-purple-500 p-6">
              <div className="text-center mb-6">
                <div className="text-purple-600 text-3xl mb-2">⭐</div>
                <h4 className="font-bold text-xl mb-2">PREMIUM</h4>
                <p className="text-gray-600 text-sm">Inspection vidéo</p>
              </div>
              <div className="space-y-3 text-sm">
                <div>Tous types: <span className="text-purple-600 font-bold">15 €/m²</span></div>
                <div className="text-gray-600 text-xs pt-2 border-t">+ Inspection vidéo complète</div>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-6 bg-gradient-to-r from-green-500 to-teal-500 text-white">
              <h4 className="font-bold text-lg mb-4">📊 Exemples concrets</h4>
              <div className="space-y-3 text-sm">
                <div>Voilier 10 m ≈ 15 m² → <span className="font-bold">120 - 225 €</span></div>
                <div>Moteur 12 m ≈ 18 m² → <span className="font-bold">162 - 270 €</span></div>
                <div>Catamaran 12 m ≈ 26,4 m² → <span className="font-bold">264 - 396 €</span></div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-r from-green-500 to-blue-600 text-white">
              <h4 className="font-bold text-lg mb-4">📋 Devis sur demande</h4>
              <p className="text-sm mb-4">Tarifs non exhaustifs</p>
              <p className="text-sm">Prix ajustés selon l'état réel de la coque</p>
            </Card>
          </div>

          <div className="mt-8 bg-gray-100 rounded-lg p-4 text-center text-sm text-gray-700">
            ✓ TTC – Assurance incluse – Déplacement inclus
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-gray-900 mb-12">Contactez-nous pour un devis gratuit</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <Card className="p-6 flex gap-4 items-start">
                <div className="bg-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl flex-shrink-0">
                  ☎️
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Téléphone</h4>
                  <p className="text-2xl font-bold text-gray-900">06 52 91 05 80</p>
                </div>
              </Card>

              <Card className="p-6 flex gap-4 items-start">
                <div className="bg-blue-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl flex-shrink-0">
                  ✉️
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">Courriel</h4>
                  <p className="text-xl font-bold text-gray-900">sent@ik.me</p>
                </div>
              </Card>
            </div>

            <Card className="p-8 bg-gradient-to-r from-green-500 to-blue-600 text-white">
              <div className="flex gap-3 mb-4">
                <span className="text-3xl">🚤</span>
                <div>
                  <h4 className="font-bold text-lg">Zone d'intervention</h4>
                  <p className="text-sm">Intervention sur <span className="font-semibold">tous les ports de la région</span></p>
                </div>
              </div>
              <div className="border-t border-white border-opacity-30 pt-6 mt-6">
                <div className="flex gap-3">
                  <span className="text-3xl">💡</span>
                  <div>
                    <h4 className="font-bold text-lg">Conseil</h4>
                    <p className="text-sm">Maintenant que vous avez un bateau propre, profitez de vos navigations en toute sérénité !</p>
                  </div>
                </div>
              </div>
              <p className="text-xs text-center mt-6 opacity-80">Réponse rapide et professionnelle garantie</p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-green-500 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Prêt à nettoyer votre bateau ?</h3>
          <p className="text-white mb-8 text-lg">Obtenez un devis gratuit en quelques minutes</p>
          <Button 
            onClick={() => setIsReservationOpen(true)}
            className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold"
          >
            Réserver maintenant
          </Button>
        </div>
      </section>

      {/* Reservation Modal */}
      <ReservationModal 
        isOpen={isReservationOpen}
        onClose={() => setIsReservationOpen(false)}
      />
    </div>
  );
}
