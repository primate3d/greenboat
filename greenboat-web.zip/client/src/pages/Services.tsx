import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Droplets, Leaf, Clock, Shield } from "lucide-react";

export default function Services() {
  const [, setLocation] = useLocation();

  const services = [
    {
      icon: Droplets,
      title: "Nettoyage Écologique",
      description: "Nettoyage professionnel utilisant des produits respectueux de l'environnement et des techniques innovantes pour préserver les écosystèmes marins.",
    },
    {
      icon: Leaf,
      title: "Produits Biodégradables",
      description: "Tous nos produits de nettoyage sont 100% biodégradables et certifiés écologiques pour minimiser l'impact environnemental.",
    },
    {
      icon: Clock,
      title: "Service Rapide",
      description: "Intervention de 2 heures pour nettoyer votre carène complètement. Créneaux horaires flexibles adaptés à votre emploi du temps.",
    },
    {
      icon: Shield,
      title: "Garantie Qualité",
      description: "Résultat garantissant l'élimination complète des algues, coquillages et autres dépôts. Satisfaction client assurée.",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="bg-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Nos Services</h1>
          <p className="text-blue-100 text-lg">
            Découvrez nos solutions complètes de nettoyage écologique pour votre bateau
          </p>
        </div>
      </div>

      {/* Services Grid */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <CardTitle>{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Pricing Section */}
        <div className="bg-gray-50 rounded-lg p-8 mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Tarification</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Petit Bateau</CardTitle>
                <CardDescription>Jusqu'à 8 mètres</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600 mb-4">50€</div>
                <ul className="space-y-2 text-sm text-gray-600 mb-6">
                  <li>✓ Nettoyage complet</li>
                  <li>✓ 2 heures d'intervention</li>
                  <li>✓ Produits écologiques</li>
                  <li>✓ Garantie satisfaction</li>
                </ul>
                <Button
                  className="w-full"
                  onClick={() => setLocation("/booking")}
                >
                  Réserver
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-600 relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  Populaire
                </span>
              </div>
              <CardHeader>
                <CardTitle>Bateau Moyen</CardTitle>
                <CardDescription>De 8 à 12 mètres</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600 mb-4">75€</div>
                <ul className="space-y-2 text-sm text-gray-600 mb-6">
                  <li>✓ Nettoyage complet</li>
                  <li>✓ 2 heures d'intervention</li>
                  <li>✓ Produits écologiques</li>
                  <li>✓ Garantie satisfaction</li>
                  <li>✓ Rapport détaillé</li>
                </ul>
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => setLocation("/booking")}
                >
                  Réserver
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle>Grand Bateau</CardTitle>
                <CardDescription>Plus de 12 mètres</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600 mb-4">À partir de 100€</div>
                <ul className="space-y-2 text-sm text-gray-600 mb-6">
                  <li>✓ Nettoyage complet</li>
                  <li>✓ 2 heures d'intervention</li>
                  <li>✓ Produits écologiques</li>
                  <li>✓ Garantie satisfaction</li>
                  <li>✓ Devis personnalisé</li>
                </ul>
                <Button
                  className="w-full"
                  onClick={() => setLocation("/booking")}
                >
                  Réserver
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-blue-600 text-white rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Prêt à nettoyer votre bateau ?</h2>
          <p className="text-blue-100 mb-6 text-lg">
            Réservez dès maintenant votre créneau de nettoyage écologique
          </p>
          <Button
            size="lg"
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={() => setLocation("/booking")}
          >
            Réserver Maintenant
          </Button>
        </div>
      </div>
    </div>
  );
}
