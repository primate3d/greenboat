import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Footer } from "@/components/Footer";

export default function MentionsLegales() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    document.title = "Mentions Légales - Green Boat";
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1
            className="text-2xl font-bold text-blue-600 cursor-pointer"
            onClick={() => setLocation("/")}
          >
            Green Boat
          </h1>
          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={() => setLocation("/services")}
            >
              Services
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/contact")}
            >
              Contact
            </Button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">
            Mentions Légales
          </h1>

          <article className="prose prose-lg max-w-none space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Informations légales
              </h2>
              <p className="text-gray-700 mb-4">
                <strong>Entreprise</strong> : Green Boat SARL
              </p>
              <p className="text-gray-700 mb-4">
                <strong>Siège social</strong> : Port d'Arcachon, 33120 Arcachon,
                France
              </p>
              <p className="text-gray-700 mb-4">
                <strong>SIRET</strong> : [À compléter]
              </p>
              <p className="text-gray-700">
                <strong>Responsable</strong> : [Nom du gérant]
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Zones d'intervention
              </h2>
              <p className="text-gray-700 mb-4">
                Green Boat intervient exclusivement en Nouvelle-Aquitaine sur
                les régions suivantes :
              </p>
              <ul className="text-gray-700 space-y-2 mb-4">
                <li>
                  <strong>Gironde (33)</strong> : Arcachon, La Teste-de-Buch,
                  Cap-Ferret, Gujan-Mestras, Arès, Andernos-les-Bains
                </li>
                <li>
                  <strong>Landes (40)</strong> : Hossegor, Capbreton,
                  Seignosse, Mimizan, Moliets, Messanges
                </li>
                <li>
                  <strong>Pays Basque (64)</strong> : Saint-Jean-de-Luz,
                  Hendaye, Ciboure, Socoa, Urrugne
                </li>
              </ul>
              <p className="text-gray-700">
                <strong>Services</strong> : Nettoyage bateau à quai - intervention
                directe ponton, coque, pont, cabine, antifouling, cirage
                gelcoat.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Conditions d'utilisation
              </h2>
              <p className="text-gray-700 mb-4">
                Le site greenboat.fr est fourni à titre informatif. Green Boat
                décline toute responsabilité pour les erreurs ou omissions. Les
                tarifs et disponibilités sont sujets à modification sans préavis.
              </p>
              <p className="text-gray-700">
                L'utilisation du site implique l'acceptation de ces conditions
                d'utilisation. Green Boat se réserve le droit de modifier ces
                conditions à tout moment.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Données personnelles
              </h2>
              <p className="text-gray-700 mb-4">
                Green Boat respecte la RGPD (Règlement Général sur la Protection
                des Données). Les données collectées via le formulaire de
                réservation sont utilisées exclusivement pour la gestion de votre
                demande. Aucune donnée n'est partagée avec des tiers.
              </p>
              <p className="text-gray-700 mb-4">
                Vous disposez d'un droit d'accès, de rectification et de
                suppression de vos données personnelles. Pour exercer ces droits,
                contactez-nous à contact@greenboat.fr.
              </p>
              <p className="text-gray-700">
                Les données sont conservées pendant la durée nécessaire à la
                gestion de votre réservation, puis supprimées conformément à la
                loi.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Propriété intellectuelle
              </h2>
              <p className="text-gray-700 mb-4">
                Tous les contenus du site (textes, images, logos, vidéos) sont
                la propriété de Green Boat ou de ses partenaires. Toute
                reproduction, distribution ou transmission sans autorisation
                écrite est interdite.
              </p>
              <p className="text-gray-700">
                Les marques et logos utilisés sur le site sont des marques
                déposées de Green Boat ou de tiers autorisés.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Limitation de responsabilité
              </h2>
              <p className="text-gray-700 mb-4">
                Green Boat ne peut être tenue responsable des dommages directs
                ou indirects résultant de l'utilisation du site ou de ses
                services. Cela inclut les pertes de données, les interruptions
                de service ou les erreurs de contenu.
              </p>
              <p className="text-gray-700">
                Green Boat s'efforce de maintenir le site en bon état de
                fonctionnement, mais ne garantit pas l'absence d'erreurs ou
                d'interruptions.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Cookies
              </h2>
              <p className="text-gray-700 mb-4">
                Le site utilise des cookies pour améliorer l'expérience
                utilisateur et analyser le trafic. En utilisant le site, vous
                acceptez l'utilisation de cookies.
              </p>
              <p className="text-gray-700">
                Vous pouvez désactiver les cookies dans les paramètres de votre
                navigateur, mais cela peut affecter le fonctionnement du site.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Liens externes
              </h2>
              <p className="text-gray-700">
                Le site peut contenir des liens vers des sites externes. Green
                Boat ne contrôle pas le contenu de ces sites et décline toute
                responsabilité pour leur contenu. L'accès à ces sites se fait
                sous votre propre responsabilité.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Contact
              </h2>
              <p className="text-gray-700 mb-4">
                Pour toute question concernant ces mentions légales ou le site,
                contactez-nous :
              </p>
              <p className="text-gray-700">
                <strong>Email</strong> : contact@greenboat.fr
              </p>
              <p className="text-gray-700">
                <strong>Adresse</strong> : Port d'Arcachon, 33120 Arcachon,
                France
              </p>
            </div>

            <div className="bg-blue-50 p-6 rounded-lg border border-blue-200 mt-8">
              <p className="text-gray-700 text-sm">
                <strong>Dernière mise à jour</strong> : 15 février 2026
              </p>
            </div>
          </article>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
