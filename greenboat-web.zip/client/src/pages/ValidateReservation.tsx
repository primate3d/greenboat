import { useEffect, useState } from "react";
import { useSearchParams } from "wouter";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

export default function ValidateReservation() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState("");
  const [reservation, setReservation] = useState<any>(null);

  const quoteNumber = searchParams.get("quote") || "";

  const getReservationQuery = trpc.booking.getByQuoteNumber.useQuery(
    { quoteNumber },
    { enabled: !!quoteNumber }
  );

  useEffect(() => {
    if (!quoteNumber) {
      setStatus("error");
      setMessage("Numéro de devis manquant");
      return;
    }

    if (getReservationQuery.isLoading) {
      setStatus("loading");
      return;
    }

    if (getReservationQuery.error) {
      setStatus("error");
      setMessage("Réservation non trouvée");
      return;
    }

    if (getReservationQuery.data) {
      setReservation(getReservationQuery.data);
      setStatus("success");
      setMessage("Votre réservation a été trouvée avec succès !");
    }
  }, [quoteNumber, getReservationQuery.isLoading, getReservationQuery.error, getReservationQuery.data]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full">
        {status === "loading" && (
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Vérification en cours</h1>
            <p className="text-gray-600">Veuillez patienter...</p>
          </div>
        )}

        {status === "success" && reservation && (
          <div className="text-center">
            <div className="text-5xl mb-4">✓</div>
            <h1 className="text-2xl font-bold text-green-600 mb-4">Réservation Confirmée !</h1>
            <p className="text-gray-600 mb-6">{message}</p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 text-left">
              <p className="text-sm text-green-800 mb-2">
                <strong>Numéro de devis :</strong> {reservation.quoteNumber}
              </p>
              <p className="text-sm text-green-800 mb-2">
                <strong>Bateau :</strong> {reservation.boatName || "Non spécifié"}
              </p>
              <p className="text-sm text-green-800 mb-2">
                <strong>Montant :</strong> {(reservation.totalPrice / 100).toFixed(2)}€
              </p>
              <p className="text-sm text-green-800">
                <strong>Statut :</strong> {reservation.status === "pending" ? "En attente" : "Confirmée"}
              </p>
            </div>
            <p className="text-sm text-gray-600 mb-6">
              Un email de confirmation a été envoyé à <strong>{reservation.clientEmail}</strong>
            </p>
            <Link href="/">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Retour à l'accueil
              </Button>
            </Link>
          </div>
        )}

        {status === "error" && (
          <div className="text-center">
            <div className="text-5xl mb-4">✗</div>
            <h1 className="text-2xl font-bold text-red-600 mb-4">Erreur</h1>
            <p className="text-gray-600 mb-6">{message}</p>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-red-800">
                <strong>Possible raisons :</strong>
              </p>
              <ul className="text-sm text-red-800 mt-2 space-y-1">
                <li>• Le numéro de devis est invalide</li>
                <li>• La réservation n'existe pas</li>
                <li>• Veuillez vérifier le lien dans votre email</li>
              </ul>
            </div>
            <Link href="/">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Retour à l'accueil
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
