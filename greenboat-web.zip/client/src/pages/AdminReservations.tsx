import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { formatPrice, formatDateFR } from "../../../shared/utils";

export default function AdminReservations() {
  const { user, isAuthenticated } = useAuth();
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  // Vérifier que l'utilisateur est admin
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Accès Refusé</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">Vous n'avez pas les permissions pour accéder à cette page.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: reservations, isLoading } = trpc.booking.list.useQuery({
    status: statusFilter || undefined,
  });

  const filteredReservations = reservations?.filter((res: any) =>
    searchQuery === ""
      ? true
      : res.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        res.clientEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        res.quoteNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "confirmed":
        return "bg-blue-100 text-blue-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return "En attente";
      case "confirmed":
        return "Confirmée";
      case "completed":
        return "Complétée";
      case "cancelled":
        return "Annulée";
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestion des Réservations</h1>
          <p className="text-gray-600">Consultez et gérez toutes les réservations de nettoyage de carènes</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="search">Rechercher</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                  <Input
                    id="search"
                    placeholder="Nom, email ou numéro de devis"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="status">Statut</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tous les statuts" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tous les statuts</SelectItem>
                    <SelectItem value="pending">En attente</SelectItem>
                    <SelectItem value="confirmed">Confirmée</SelectItem>
                    <SelectItem value="completed">Complétée</SelectItem>
                    <SelectItem value="cancelled">Annulée</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Reservations List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin" />
          </div>
        ) : filteredReservations && filteredReservations.length > 0 ? (
          <div className="space-y-4">
            {filteredReservations.map((reservation: any) => (
              <Card key={reservation.id} className="hover:shadow-md transition-shadow">
                <div
                  className="p-6 cursor-pointer"
                  onClick={() => setExpandedId(expandedId === reservation.id ? null : reservation.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{reservation.clientName}</h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadgeColor(reservation.status)}`}>
                          {getStatusLabel(reservation.status)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">
                        Devis: <span className="font-mono font-semibold">{reservation.quoteNumber}</span>
                      </p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Date</p>
                          <p className="font-semibold">{formatDateFR(new Date(reservation.reservationDate))}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Horaire</p>
                          <p className="font-semibold">{reservation.startTime} - {reservation.endTime}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Bateau</p>
                          <p className="font-semibold">{reservation.boatLength / 10}m</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Prix</p>
                          <p className="font-semibold text-blue-600">{formatPrice(reservation.totalPrice)}</p>
                        </div>
                      </div>
                    </div>
                    <ChevronDown
                      className={`text-gray-400 transition-transform ${expandedId === reservation.id ? "rotate-180" : ""}`}
                      size={24}
                    />
                  </div>
                </div>

                {/* Expanded Details */}
                {expandedId === reservation.id && (
                  <div className="border-t px-6 py-4 bg-gray-50">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Informations Client</h4>
                        <div className="space-y-2 text-sm">
                          <p>
                            <span className="text-gray-600">Nom:</span> {reservation.clientName}
                          </p>
                          <p>
                            <span className="text-gray-600">Email:</span> {reservation.clientEmail}
                          </p>
                          <p>
                            <span className="text-gray-600">Téléphone:</span> {reservation.clientPhone}
                          </p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Informations Bateau</h4>
                        <div className="space-y-2 text-sm">
                          <p>
                            <span className="text-gray-600">Nom:</span> {reservation.boatName || "Non spécifié"}
                          </p>
                          <p>
                            <span className="text-gray-600">Longueur:</span> {reservation.boatLength / 10}m
                          </p>
                          <p>
                            <span className="text-gray-600">Surface:</span> {reservation.surface / 100}m²
                          </p>
                          <p>
                            <span className="text-gray-600">Port:</span> {reservation.portAddress}
                          </p>
                          <p>
                            <span className="text-gray-600">Emplacement:</span> {reservation.boatLocation}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t">
                      <h4 className="font-semibold text-gray-900 mb-3">Tarification</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Prix de base:</span>
                          <span className="font-semibold">{formatPrice(reservation.basePrice)}</span>
                        </div>
                        <div className="flex justify-between border-t pt-2">
                          <span className="font-semibold">Prix Total:</span>
                          <span className="font-bold text-blue-600">{formatPrice(reservation.totalPrice)}</span>
                        </div>
                      </div>
                    </div>
                    {reservation.notes && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-semibold text-gray-900 mb-2">Notes</h4>
                        <p className="text-sm text-gray-600">{reservation.notes}</p>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-gray-600">Aucune réservation trouvée</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
