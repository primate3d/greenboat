import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { ArticleSchema } from "@/components/SEOSchema";

export default function Blog() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    document.title =
      "Nettoyage Bateau Hiver Nouvelle-Aquitaine | Green Boat";
  }, []);

  return (
    <>
      <ArticleSchema
        title="Pourquoi faire nettoyer son bateau à quai en hiver en Nouvelle-Aquitaine ?"
        description="Guide complet : découvrez les avantages du nettoyage bateau à quai en hiver et comment Green Boat intervient même en conditions hivernales."
        datePublished="2026-02-15"
        dateModified="2026-02-15"
        author="Green Boat"
        image="https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/MnVPGllwfawHUrFe.jpg"
      />
      <div className="min-h-screen bg-white">
        {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1
            className="text-2xl font-bold text-blue-600 cursor-pointer"
            onClick={() => setLocation("/")}
          >
            Green Boat
          </h1>
          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={() => setLocation("/services")}
            >
              Services
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/contact")}
            >
              Contact
            </Button>
          </div>
        </div>
      </nav>

      {/* Article Header */}
      <section className="bg-gradient-to-r from-blue-50 to-indigo-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="mb-4">
            <span className="text-blue-600 font-semibold">Blog</span>
            <span className="text-gray-400 mx-2">•</span>
            <span className="text-gray-600">15 février 2026</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Pourquoi faire nettoyer son bateau à quai en hiver en
            Nouvelle-Aquitaine ?
          </h1>
          <p className="text-xl text-gray-700">
            Guide complet : découvrez les avantages du nettoyage bateau à quai
            en hiver et comment Green Boat intervient même en conditions
            hivernales.
          </p>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Introduction
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              L'hiver en Nouvelle-Aquitaine apporte des conditions maritimes
              particulières : tempêtes atlantiques, marées fortes, accumulation
              d'algues brunes et dépôts calcaires. C'est paradoxalement la
              meilleure période pour faire nettoyer son bateau à quai. Découvrez
              pourquoi et comment Green Boat intervient même en hiver.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Pourquoi l'hiver est la saison idéale pour le nettoyage bateau
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              L'hiver en Nouvelle-Aquitaine (novembre à février) offre des
              conditions uniques pour le nettoyage bateau à quai. Les tempêtes
              atlantiques créent une accumulation rapide de sel, d'algues rouges
              et de dépôts organiques sur les coques. Les propriétaires de
              bateaux à Arcachon, Hossegor et Saint-Jean-de-Luz font face à des
              défis spécifiques.
            </p>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Entre novembre et février, les bateaux sont moins utilisés pour la
              navigation. C'est l'occasion idéale pour intervenir à quai sans
              perturber vos plans de sortie. Les conditions météorologiques
              hivernales, bien que rudes, permettent un nettoyage plus efficace
              : l'eau froide aide à éliminer les dépôts calcaires et les algues.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Les défis spécifiques de l'hiver Nouvelle-Aquitaine
            </h2>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Accumulation de sel
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Les tempêtes atlantiques projettent du sel sur les coques. Ce sel
              s'accumule et crée une croûte qui ternit la gelcoat et corrode les
              métaux. Le nettoyage hiver élimine cette croûte avant qu'elle ne
              cause des dégâts permanents. À Arcachon, le bassin ostréicole
              amplifie cette accumulation due à la proximité de l'eau salée.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Algues brunes et rouges
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              En hiver, les algues brunes (fucus) et rouges (corallines)
              colonisent les coques. Ces algues sont plus difficiles à éliminer
              au printemps. Un nettoyage hiver prévient cette prolifération et
              maintient votre bateau en excellent état. Les conditions froides
              ralentissent la croissance des algues mais favorisent leur
              adhérence à la coque.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Dépôts calcaires
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              L'eau froide de l'Atlantique crée des dépôts calcaires sur les
              coques. Ces dépôts s'épaississent avec le temps et deviennent très
              difficiles à enlever. Le nettoyage hiver les élimine facilement
              avant qu'ils ne deviennent incrustés. Green Boat utilise des
              techniques écologiques pour éliminer ces dépôts sans endommager la
              gelcoat.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Antifouling usé
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              L'antifouling (peinture anti-algues) s'use plus vite en hiver. Un
              nettoyage hiver permet d'inspecter l'état de l'antifouling et de
              le renouveler si nécessaire avant la saison estivale. C'est
              l'occasion idéale pour préparer votre bateau pour les sorties
              printanières.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Services de nettoyage bateau à quai en hiver
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Green Boat propose des services complets de nettoyage bateau à
              quai en hiver, spécialement adaptés aux conditions hivernales de
              Nouvelle-Aquitaine.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h4 className="text-xl font-bold text-gray-900 mb-3">
                  Nettoyage coque
                </h4>
                <p className="text-gray-700">
                  Élimination du sel, algues, dépôts calcaires. Inspection de
                  l'antifouling. Renouvellement si nécessaire.
                </p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h4 className="text-xl font-bold text-gray-900 mb-3">
                  Nettoyage pont
                </h4>
                <p className="text-gray-700">
                  Élimination des algues, dépôts organiques, sel. Nettoyage des
                  joints et des zones difficiles d'accès.
                </p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h4 className="text-xl font-bold text-gray-900 mb-3">
                  Nettoyage cabine
                </h4>
                <p className="text-gray-700">
                  Intérieur du bateau, élimination de l'humidité hivernale,
                  nettoyage des vitres et hublots.
                </p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h4 className="text-xl font-bold text-gray-900 mb-3">
                  Cirage gelcoat
                </h4>
                <p className="text-gray-700">
                  Restauration de la brillance et de la protection de la gelcoat
                  après nettoyage.
                </p>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Zones d'intervention en Nouvelle-Aquitaine
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Green Boat intervient sur les pontons de 15 villes prioritaires en
              Nouvelle-Aquitaine. Intervention directe ponton, sans besoin de
              sortir votre bateau de l'eau. Équipes professionnelles, techniques
              écologiques, tarification transparente.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-8">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Gironde (33)</h4>
                <ul className="text-gray-700 space-y-2 text-sm">
                  <li>• Arcachon</li>
                  <li>• La Teste-de-Buch</li>
                  <li>• Cap-Ferret</li>
                  <li>• Gujan-Mestras</li>
                  <li>• Arès</li>
                  <li>• Andernos-les-Bains</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Landes (40)</h4>
                <ul className="text-gray-700 space-y-2 text-sm">
                  <li>• Hossegor</li>
                  <li>• Capbreton</li>
                  <li>• Seignosse</li>
                  <li>• Mimizan</li>
                  <li>• Moliets</li>
                  <li>• Messanges</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">
                  Pays Basque (64)
                </h4>
                <ul className="text-gray-700 space-y-2 text-sm">
                  <li>• Saint-Jean-de-Luz</li>
                  <li>• Hendaye</li>
                  <li>• Ciboure</li>
                  <li>• Socoa</li>
                  <li>• Urrugne</li>
                </ul>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Avantages du nettoyage bateau à quai en hiver
            </h2>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Économies
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Pas de frais de sortie bateau. Intervention rapide (2 heures en
              moyenne). Tarification réduite en basse saison. Green Boat propose
              des tarifs spéciaux pour les interventions hivernales.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Prévention
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Élimination des dépôts avant qu'ils ne causent des dégâts.
              Inspection de l'antifouling. Prévention de la corrosion. Un
              nettoyage régulier en hiver prolonge la durée de vie de votre
              bateau.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Écologie
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Techniques respectueuses de l'environnement. Produits
              biodégradables. Respect des écosystèmes côtiers (ostréiculture,
              pêche). Green Boat s'engage pour la protection de la
              Nouvelle-Aquitaine maritime.
            </p>

            <h3 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Confort
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Intervention à quai. Vous restez à bord ou profitez d'une pause.
              Pas de perturbation de vos plans. Nos équipes travaillent
              efficacement et respectueusement.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mb-6 mt-12">
              Conclusion
            </h2>
            <p className="text-gray-700 mb-6 leading-relaxed">
              L'hiver en Nouvelle-Aquitaine est la saison idéale pour faire
              nettoyer son bateau à quai. Green Boat propose des services
              professionnels, écologiques et abordables. Contactez-nous pour un
              devis gratuit et réservez votre nettoyage bateau à quai en hiver.
              Nos équipes sont prêtes à intervenir à Arcachon, Hossegor,
              Saint-Jean-de-Luz et dans toutes les villes de Nouvelle-Aquitaine.
            </p>
          </article>

          {/* CTA */}
          <div className="bg-blue-50 p-8 rounded-lg border border-blue-200 mt-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Prêt à nettoyer votre bateau ?
            </h3>
            <p className="text-gray-700 mb-6">
              Réservez votre nettoyage bateau à quai en hiver. Intervention
              rapide, tarification transparente, devis gratuit.
            </p>
            <Button
              size="lg"
              onClick={() => setLocation("/booking")}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Réserver maintenant
            </Button>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Articles connexes
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                Antifouling bateau : quand et comment renouveler
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Guide complet sur le renouvellement de l'antifouling pour
                protéger votre bateau.
              </p>
              <a href="#" className="text-blue-600 font-semibold text-sm">
                Lire l'article →
              </a>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                Cirage gelcoat : restaurer la brillance de votre bateau
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Conseils et techniques pour maintenir la brillance de votre
                gelcoat.
              </p>
              <a href="#" className="text-blue-600 font-semibold text-sm">
                Lire l'article →
              </a>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                Nettoyage bateau printemps : préparation saison estivale
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Préparez votre bateau pour l'été avec un nettoyage complet au
                printemps.
              </p>
              <a href="#" className="text-blue-600 font-semibold text-sm">
                Lire l'article →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p>
            &copy; 2026 Green Boat - Nettoyage Bateau à Quai. Tous droits
            réservés.
          </p>
          <p className="mt-2 text-gray-400">
            Intervention directe ponton | Écologique | Nouvelle-Aquitaine
          </p>
        </div>
      </footer>
    </div>
    </>
  );
}
