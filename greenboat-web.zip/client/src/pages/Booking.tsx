import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, CheckCircle, AlertCircle, Calendar, Clock } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { bookingSchema, type BookingData } from "../../../shared/schemas";
import { formatPrice } from "../../../shared/utils";

type Step = 1 | 2 | 3 | 4;

interface FormData {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  boatName: string;
  boatBrand: string;
  boatModel: string;
  boatCategory: "voilier" | "moteur" | "autre";
  boatLength: number;
  boatLengthAtWaterline: number;
  boatWidth: number;
  boatDraft: number;
  surface: number;
  portAddress: string;
  quai: string;
  emplacement: string;
  zoneId: number;
  reservationDate: string;
  startTime: string;
  endTime: string;
}

interface TimeSlot {
  id: number;
  startTime: string;
  endTime: string;
  available: boolean;
}

export default function Booking() {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [formData, setFormData] = useState<Partial<FormData>>({
    boatLength: 10,
    surface: 25,
    boatCategory: "moteur",
    zoneId: 1, // Zone par défaut
  });
  const [successData, setSuccessData] = useState<{ quoteNumber: string; totalPrice: number } | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const { data: timeSlots, isLoading: timeSlotsLoading } = trpc.booking.getAvailableTimeSlots.useQuery(
    {
      date: formData.reservationDate ? new Date(formData.reservationDate) : new Date(),
    },
    { enabled: !!formData.reservationDate }
  );

  const createReservation = trpc.booking.create.useMutation({
    onSuccess: (data) => {
      setSuccessData(data);
      setCurrentStep(4);
      toast.success("Réservation créée avec succès !");
    },
    onError: (error) => {
      toast.error(`Erreur: ${error.message}`);
    },
  });

  const validateStep = async (step: Step): Promise<boolean> => {
    try {
      if (step === 1) {
        // Valider étape 1: Informations personnelles
        const clientInfoData = {
          name: formData.clientName || "",
          email: formData.clientEmail || "",
          phone: formData.clientPhone || "",
        };
        const { clientInfoSchema } = await import("../../../shared/schemas");
        await clientInfoSchema.parseAsync(clientInfoData);
        return true;
      } else if (step === 2) {
        // Valider étape 2: Détails du bateau
        const boatInfoData = {
          name: formData.boatName || "",
          category: formData.boatCategory || "moteur",
          length: formData.boatLength || 0,
          surface: formData.surface || 0,
          portAddress: formData.portAddress || "",
          quai: formData.quai || "",
          emplacement: formData.emplacement || "",
        };
        const { boatInfoSchema } = await import("../../../shared/schemas");
        await boatInfoSchema.parseAsync(boatInfoData);
        return true;
      } else if (step === 3) {
        // Valider étape 3: Date et horaire
        if (!formData.reservationDate) {
          toast.error("Veuillez sélectionner une date");
          return false;
        }
        if (!formData.startTime || !formData.endTime) {
          toast.error("Veuillez sélectionner un horaire");
          return false;
        }
        return true;
      }
      return true;
    } catch (error: any) {
      const errorMessage = error.errors?.[0]?.message || error.message || "Erreur de validation";
      toast.error(errorMessage);
      return false;
    }
  };

  const handleNext = async () => {
    if (currentStep < 4) {
      const isValid = await validateStep(currentStep);
      if (isValid) {
        setCurrentStep((currentStep + 1) as Step);
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep((currentStep - 1) as Step);
    }
  };

  const handleSubmit = async () => {
    try {
      // Convertir la date string en Date pour validation
      const dateStr = formData.reservationDate || "";
      const dateObj = new Date(dateStr + "T00:00:00");
      
      const bookingData: BookingData = {
        clientName: formData.clientName || "",
        clientEmail: formData.clientEmail || "",
        clientPhone: formData.clientPhone || "",
        boatName: formData.boatName || "",
        boatBrand: formData.boatBrand || "",
        boatModel: formData.boatModel || "",
        boatCategory: formData.boatCategory || "moteur",
        boatLength: formData.boatLength || 0,
        boatLengthAtWaterline: formData.boatLengthAtWaterline || formData.boatLength || 0,
        boatWidth: formData.boatWidth || 0,
        boatDraft: formData.boatDraft || 0,
        surface: formData.surface || 0,
        portAddress: formData.portAddress || "",
        quai: formData.quai || "",
        emplacement: formData.emplacement || "",
        zoneId: formData.zoneId || 1,
        reservationDate: dateObj,
        startTime: formData.startTime || "",
        endTime: formData.endTime || "",
      };

      await bookingSchema.parseAsync(bookingData);
      await createReservation.mutateAsync(bookingData);
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de la validation");
    }
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split("T")[0];
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "voilier":
        return "Voilier";
      case "moteur":
        return "Moteur";
      case "autre":
        return "Autre";
      default:
        return category;
    }
  };

  const stepTitles: Record<Step, string> = {
    1: "Informations Personnelles",
    2: "Détails du Bateau",
    3: "Date et Horaire d'Intervention",
    4: "Réservation Confirmée",
  };

  const stepDescriptions: Record<Step, string> = {
    1: "Étape 1/3 - Vos coordonnées",
    2: "Étape 2/3 - Informations de votre bateau",
    3: "Étape 3/3 - Sélectionnez votre date et horaire",
    4: "Votre réservation a été confirmée",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Green Boat</h1>
          <p className="text-lg text-gray-600">Nettoyage Écologique de Carènes</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-4">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`flex items-center justify-center w-10 h-10 rounded-full font-bold ${
                  step === currentStep
                    ? "bg-blue-600 text-white"
                    : step < currentStep
                    ? "bg-green-600 text-white"
                    : "bg-gray-300 text-gray-600"
                }`}
              >
                {step < currentStep ? "✓" : step}
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            />
          </div>
        </div>

        {/* Form Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>{stepTitles[currentStep]}</CardTitle>
            <CardDescription>{stepDescriptions[currentStep]}</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Step 1: Client Info */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nom complet *</Label>
                  <Input
                    id="name"
                    placeholder="Jean Dupont"
                    value={formData.clientName || ""}
                    onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="jean@example.com"
                    value={formData.clientEmail || ""}
                    onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Téléphone (06/07) *</Label>
                  <Input
                    id="phone"
                    placeholder="06 12 34 56 78"
                    value={formData.clientPhone || ""}
                    onChange={(e) => setFormData({ ...formData, clientPhone: e.target.value })}
                  />
                </div>
              </div>
            )}

            {/* Step 2: Boat Info */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="boatName">Nom du bateau</Label>
                  <Input
                    id="boatName"
                    placeholder="Ex: Mon Bateau"
                    value={formData.boatName || ""}
                    onChange={(e) => setFormData({ ...formData, boatName: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="category">Catégorie du bateau *</Label>
                  <Select value={formData.boatCategory || "moteur"} onValueChange={(value) => setFormData({ ...formData, boatCategory: value as "voilier" | "moteur" | "autre" })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez une catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="voilier">Voilier</SelectItem>
                      <SelectItem value="moteur">Moteur</SelectItem>
                      <SelectItem value="autre">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="length">Longueur (m) *</Label>
                    <Input
                      id="length"
                      type="number"
                      min="2"
                      max="100"
                      step="0.5"
                      value={formData.boatLength || ""}
                      onChange={(e) => setFormData({ ...formData, boatLength: parseFloat(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="surface">Surface (m²) *</Label>
                    <Input
                      id="surface"
                      type="number"
                      min="1"
                      max="500"
                      step="0.5"
                      value={formData.surface || ""}
                      onChange={(e) => setFormData({ ...formData, surface: parseFloat(e.target.value) })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="portAddress">Adresse du port *</Label>
                  <Input
                    id="portAddress"
                    placeholder="Ex: Port de Marseille"
                    value={formData.portAddress || ""}
                    onChange={(e) => setFormData({ ...formData, portAddress: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quai">Quai *</Label>
                    <Input
                      id="quai"
                      placeholder="Ex: Quai 3"
                      value={formData.quai || ""}
                      onChange={(e) => setFormData({ ...formData, quai: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="emplacement">Emplacement *</Label>
                    <Input
                      id="emplacement"
                      placeholder="Ex: Ponton A"
                      value={formData.emplacement || ""}
                      onChange={(e) => setFormData({ ...formData, emplacement: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Date and Time */}
            {currentStep === 3 && (
              <div className="space-y-4">
                {/* Date Picker Button */}
                <div>
                  <Label>Date d'intervention *</Label>
                  <button
                    onClick={() => setShowDatePicker(!showDatePicker)}
                    className="w-full px-4 py-2 border-2 border-blue-600 rounded-lg text-left flex items-center gap-2 hover:bg-blue-50"
                  >
                    <Calendar size={20} />
                    {formData.reservationDate ? new Date(formData.reservationDate).toLocaleDateString("fr-FR") : "Sélectionnez une date"}
                  </button>
                  {showDatePicker && (
                    <div className="mt-2 p-4 border rounded-lg bg-white">
                      <Input
                        type="date"
                        min={getMinDate()}
                        value={formData.reservationDate || ""}
                        onChange={(e) => {
                          setFormData({ ...formData, reservationDate: e.target.value });
                          setShowDatePicker(false);
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Time Slot Picker Button */}
                {formData.reservationDate && (
                  <div>
                    <Label>Horaire d'intervention * (2 heures)</Label>
                    <button
                      onClick={() => setShowTimePicker(!showTimePicker)}
                      className="w-full px-4 py-2 border-2 border-blue-600 rounded-lg text-left flex items-center gap-2 hover:bg-blue-50"
                    >
                      <Clock size={20} />
                      {formData.startTime ? `${formData.startTime} - ${formData.endTime}` : "Sélectionnez un horaire"}
                    </button>
                    {showTimePicker && (
                      <div className="mt-2 p-4 border rounded-lg bg-white">
                        {timeSlotsLoading ? (
                          <div className="flex items-center justify-center py-4">
                            <Loader2 className="animate-spin" />
                          </div>
                        ) : timeSlots && timeSlots.length > 0 ? (
                          <div className="grid grid-cols-3 gap-2 max-h-64 overflow-y-auto">
                            {(timeSlots as TimeSlot[]).map((slot) => (
                              <button
                                key={slot.id}
                                onClick={() => {
                                  setFormData({
                                    ...formData,
                                    startTime: slot.startTime,
                                    endTime: slot.endTime,
                                  });
                                  setShowTimePicker(false);
                                }}
                                disabled={!slot.available}
                                className={`p-2 rounded-lg border-2 transition-all text-xs ${
                                  !slot.available
                                    ? "border-gray-300 bg-gray-100 text-gray-400 cursor-not-allowed"
                                    : formData.startTime === slot.startTime
                                    ? "border-blue-600 bg-blue-50 font-bold"
                                    : "border-gray-200 hover:border-blue-300"
                                }`}
                              >
                                <div className="font-semibold">{slot.startTime}</div>
                                {!slot.available && <div className="text-red-600">Occupé</div>}
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <AlertCircle className="text-yellow-600" size={18} />
                            <p className="text-sm text-yellow-800">Aucun créneau disponible pour cette date</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Step 4: Confirmation */}
            {currentStep === 4 && successData && (
              <div className="space-y-6">
                <div className="flex justify-center">
                  <CheckCircle className="w-16 h-16 text-green-600" />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Réservation Confirmée !</h3>
                  <p className="text-gray-600 mb-4">Merci pour votre confiance. Voici votre numéro de devis :</p>
                  <div className="bg-blue-50 border-2 border-blue-600 rounded-lg p-4 mb-4">
                    <p className="text-sm text-gray-600">Numéro de Devis</p>
                    <p className="text-2xl font-bold text-blue-600">{successData.quoteNumber}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 text-left space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Bateau:</span>
                      <span className="font-semibold">{formData.boatName || "Non spécifié"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Catégorie:</span>
                      <span className="font-semibold">{getCategoryLabel(formData.boatCategory || "moteur")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Longueur:</span>
                      <span className="font-semibold">{formData.boatLength} m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Surface:</span>
                      <span className="font-semibold">{formData.surface} m²</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Quai:</span>
                      <span className="font-semibold">{formData.quai}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Emplacement:</span>
                      <span className="font-semibold">{formData.emplacement}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date:</span>
                      <span className="font-semibold">{formData.reservationDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Horaire:</span>
                      <span className="font-semibold">{formData.startTime} - {formData.endTime}</span>
                    </div>
                    <div className="border-t pt-2 mt-2 flex justify-between">
                      <span className="font-semibold">Prix Total:</span>
                      <span className="text-lg font-bold text-blue-600">{formatPrice(successData.totalPrice)}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-4">Un email de confirmation a été envoyé à {formData.clientEmail}</p>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 gap-4">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1 || currentStep === 4 || createReservation.isPending}
              >
                Précédent
              </Button>
              {currentStep < 4 ? (
                <Button
                  onClick={currentStep === 3 ? handleSubmit : handleNext}
                  disabled={createReservation.isPending}
                >
                  {currentStep === 3 ? "Confirmer" : "Suivant"}
                </Button>
              ) : (
                <Button onClick={() => (window.location.href = "/")} variant="default">
                  Retour à l'accueil
                </Button>
              )}
            </div>

            {createReservation.isPending && (
              <div className="flex items-center justify-center gap-2 mt-4 text-blue-600">
                <Loader2 className="animate-spin" />
                <span>Création de votre réservation...</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
