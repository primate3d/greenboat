import { useLocation } from "wouter";

export function Footer() {
  const [, setLocation] = useLocation();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Column 1: About */}
          <div>
            <h3 className="text-lg font-bold mb-4">Green Boat</h3>
            <p className="text-gray-400 text-sm">
              Service professionnel de <strong>nettoyage bateau à quai</strong>{" "}
              en Nouvelle-Aquitaine. Intervention directe ponton. Écologique.
            </p>
          </div>

          {/* Column 2: Gironde */}
          <div>
            <h3 className="text-lg font-bold mb-4">Gironde (33)</h3>
            <ul className="text-gray-400 text-sm space-y-2">
              <li>
                <a
                  href="/villes/arcachon-nettoyage-bateau"
                  className="hover:text-white transition"
                >
                  Nettoyage bateau Arcachon
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau La Teste
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Cap-Ferret
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Gujan-Mestras
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Landes */}
          <div>
            <h3 className="text-lg font-bold mb-4">Landes (40)</h3>
            <ul className="text-gray-400 text-sm space-y-2">
              <li>
                <a
                  href="/villes/hossegor-nettoyage-bateau"
                  className="hover:text-white transition"
                >
                  Nettoyage bateau Hossegor
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Capbreton
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Seignosse
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Mimizan
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Pays Basque */}
          <div>
            <h3 className="text-lg font-bold mb-4">Pays Basque (64)</h3>
            <ul className="text-gray-400 text-sm space-y-2">
              <li>
                <a
                  href="/villes/saint-jean-de-luz-nettoyage-bateau"
                  className="hover:text-white transition"
                >
                  Nettoyage bateau Saint-Jean-de-Luz
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Hendaye
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Ciboure
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition">
                  Nettoyage bateau Socoa
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-gray-700 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-2">Services</h4>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>
                  <a href="/services#nettoyage-coque" className="hover:text-white transition">
                    Nettoyage coque
                  </a>
                </li>
                <li>
                  <a href="/services#antifouling" className="hover:text-white transition">
                    Antifouling
                  </a>
                </li>
                <li>
                  <a href="/services#cirage-gelcoat" className="hover:text-white transition">
                    Cirage gelcoat
                  </a>
                </li>
                <li>
                  <a href="/services#nettoyage-pont" className="hover:text-white transition">
                    Nettoyage pont
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-2">Informations</h4>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>
                  <a href="/blog/nettoyage-bateau-quai-hiver-nouvelle-aquitaine" className="hover:text-white transition">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="/contact" className="hover:text-white transition">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="/mentions-legales" className="hover:text-white transition">
                    Mentions légales
                  </a>
                </li>
                <li>
                  <a href="/politique-confidentialite" className="hover:text-white transition">
                    Politique de confidentialité
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-2">Zones d'intervention</h4>
              <p className="text-gray-400 text-sm">
                <strong>Nouvelle-Aquitaine</strong> : Gironde (33), Landes (40),
                Pays Basque (64). Intervention directe ponton à quai.
              </p>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-4 text-center text-gray-400 text-sm">
            <p>&copy; 2026 Green Boat - Nettoyage Bateau à Quai. Tous droits réservés.</p>
            <p className="mt-2">
              Intervention directe ponton | Écologique | Nouvelle-Aquitaine
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
