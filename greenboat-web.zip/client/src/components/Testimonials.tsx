import { Star } from "lucide-react";
import { Card } from "@/components/ui/card";

interface Testimonial {
  name: string;
  role: string;
  boat: string;
  rating: number;
  text: string;
  image: string;
}

const testimonials: Testimonial[] = [
  {
    name: "Pierre Dubois",
    role: "Propriétaire de voilier",
    boat: "Voilier 12m",
    rating: 5,
    text: "Service exceptionnel ! Mon voilier brille comme neuf. L'équipe est professionnelle et respectueuse de l'environnement. Je recommande vivement Green Boat pour tous vos besoins de nettoyage écologique.",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/MnVPGllwfawHUrFe.jpg",
  },
  {
    name: "Marie Lefevre",
    role: "Propriétaire de yacht",
    boat: "Yacht moteur 15m",
    rating: 5,
    text: "Transformation incroyable ! La carène de mon yacht était ternie, et après le service de Green Boat, elle est impeccable. Le processus écologique est rassurant et les résultats parlent d'eux-mêmes.",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/WRNhamzbFdjlPVZT.jpg",
  },
  {
    name: "Jean Martin",
    role: "Propriétaire de bateau de pêche",
    boat: "Bateau de pêche 10m",
    rating: 5,
    text: "Excellent rapport qualité-prix ! Mon bateau de pêche est maintenant en parfait état. L'équipe a terminé le travail à temps et sans déranger les autres bateaux du port. Très professionnel !",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663355584052/jeOnPCISDrywvgIN.jpg",
  },
];

export function Testimonials() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-background to-muted/30">
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
            Ce que disent nos clients
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Découvrez les témoignages de propriétaires de bateaux satisfaits par
            nos services de nettoyage écologique professionnels.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden bg-muted">
                <img
                  src={testimonial.image}
                  alt={testimonial.boat}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              </div>

              {/* Content */}
              <div className="p-6 flex flex-col flex-grow">
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>

                {/* Testimonial Text */}
                <p className="text-muted-foreground mb-6 flex-grow leading-relaxed">
                  "{testimonial.text}"
                </p>

                {/* Author Info */}
                <div className="border-t pt-4">
                  <p className="font-semibold text-foreground">
                    {testimonial.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.role}
                  </p>
                  <p className="text-xs text-primary font-medium mt-1">
                    {testimonial.boat}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-3xl font-bold text-primary">150+</p>
            <p className="text-sm text-muted-foreground mt-2">
              Bateaux nettoyés
            </p>
          </div>
          <div>
            <p className="text-3xl font-bold text-primary">98%</p>
            <p className="text-sm text-muted-foreground mt-2">
              Clients satisfaits
            </p>
          </div>
          <div>
            <p className="text-3xl font-bold text-primary">5★</p>
            <p className="text-sm text-muted-foreground mt-2">
              Note moyenne
            </p>
          </div>
          <div>
            <p className="text-3xl font-bold text-primary">100%</p>
            <p className="text-sm text-muted-foreground mt-2">
              Écologique
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
