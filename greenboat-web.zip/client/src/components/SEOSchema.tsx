import { useEffect } from "react";

interface LocalBusinessSchemaProps {
  city: "arcachon" | "hossegor" | "saint-jean-de-luz" | "general";
}

const schemaData = {
  general: {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Green Boat - Nettoyage Bateau à Quai",
    image: "https://greenboat.fr/logo.png",
    description:
      "Service professionnel de nettoyage bateau à quai en Nouvelle-Aquitaine. Intervention directe ponton, coque, pont, cabine. Écologique.",
    telephone: "+33 5 XX XX XX XX",
    email: "contact@greenboat.fr",
    url: "https://greenboat.fr",
    areaServed: [
      {
        "@type": "City",
        name: "Arcachon",
        address: {
          "@type": "PostalAddress",
          addressCountry: "FR",
          postalCode: "33120",
        },
      },
      {
        "@type": "City",
        name: "Hossegor",
        address: {
          "@type": "PostalAddress",
          addressCountry: "FR",
          postalCode: "40150",
        },
      },
      {
        "@type": "City",
        name: "Saint-Jean-de-Luz",
        address: {
          "@type": "PostalAddress",
          addressCountry: "FR",
          postalCode: "64500",
        },
      },
    ],
    address: [
      {
        "@type": "PostalAddress",
        streetAddress: "Port d'Arcachon, Ponton A",
        addressLocality: "Arcachon",
        addressRegion: "Nouvelle-Aquitaine",
        postalCode: "33120",
        addressCountry: "FR",
      },
      {
        "@type": "PostalAddress",
        streetAddress: "Port de Hossegor, Ponton B",
        addressLocality: "Hossegor",
        addressRegion: "Nouvelle-Aquitaine",
        postalCode: "40150",
        addressCountry: "FR",
      },
      {
        "@type": "PostalAddress",
        streetAddress: "Port de Saint-Jean-de-Luz, Ponton C",
        addressLocality: "Saint-Jean-de-Luz",
        addressRegion: "Nouvelle-Aquitaine",
        postalCode: "64500",
        addressCountry: "FR",
      },
    ],
    priceRange: "€€",
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        opens: "08:00",
        closes: "18:00",
      },
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Saturday"],
        opens: "09:00",
        closes: "17:00",
      },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "150",
    },
    review: [
      {
        "@type": "Review",
        author: {
          "@type": "Person",
          name: "Pierre Dubois",
        },
        datePublished: "2025-12-15",
        reviewRating: {
          "@type": "Rating",
          ratingValue: "5",
        },
        reviewBody:
          "Service exceptionnel ! Mon voilier brille comme neuf. Équipe professionnelle et respectueuse de l'environnement.",
      },
    ],
  },
  arcachon: {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Green Boat - Nettoyage Bateau à Quai Arcachon",
    description:
      "Service professionnel de nettoyage bateau à quai à Arcachon. Intervention directe ponton, coque, pont, cabine.",
    url: "https://greenboat.fr/villes/arcachon-nettoyage-bateau",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Port d'Arcachon, Ponton A",
      addressLocality: "Arcachon",
      addressRegion: "Nouvelle-Aquitaine",
      postalCode: "33120",
      addressCountry: "FR",
    },
    areaServed: [
      "Arcachon",
      "La Teste-de-Buch",
      "Cap-Ferret",
      "Gujan-Mestras",
      "Arès",
      "Andernos-les-Bains",
    ],
    priceRange: "€€",
  },
  hossegor: {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Green Boat - Nettoyage Bateau à Quai Hossegor",
    description:
      "Nettoyage bateau à quai à Hossegor et Landes. Intervention directe ponton, coque, pont.",
    url: "https://greenboat.fr/villes/hossegor-nettoyage-bateau",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Port de Hossegor, Ponton B",
      addressLocality: "Hossegor",
      addressRegion: "Nouvelle-Aquitaine",
      postalCode: "40150",
      addressCountry: "FR",
    },
    areaServed: [
      "Hossegor",
      "Capbreton",
      "Seignosse",
      "Mimizan",
      "Moliets",
      "Messanges",
    ],
    priceRange: "€€",
  },
  "saint-jean-de-luz": {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Green Boat - Nettoyage Bateau à Quai Saint-Jean-de-Luz",
    description:
      "Nettoyage bateau à quai à Saint-Jean-de-Luz, Pays Basque. Intervention directe ponton, coque, pont, cabine.",
    url: "https://greenboat.fr/villes/saint-jean-de-luz-nettoyage-bateau",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Port de Saint-Jean-de-Luz, Ponton C",
      addressLocality: "Saint-Jean-de-Luz",
      addressRegion: "Nouvelle-Aquitaine",
      postalCode: "64500",
      addressCountry: "FR",
    },
    areaServed: [
      "Saint-Jean-de-Luz",
      "Hendaye",
      "Ciboure",
      "Socoa",
      "Urrugne",
    ],
    priceRange: "€€",
  },
};

export function SEOSchema({ city }: LocalBusinessSchemaProps) {
  useEffect(() => {
    const schema = document.createElement("script");
    schema.type = "application/ld+json";
    schema.textContent = JSON.stringify(schemaData[city]);
    document.head.appendChild(schema);

    return () => {
      if (schema.parentNode) {
        schema.parentNode.removeChild(schema);
      }
    };
  }, [city]);

  return null;
}

export function BreadcrumbSchema({ items }: { items: Array<{ name: string; url: string }> }) {
  useEffect(() => {
    const schema = document.createElement("script");
    schema.type = "application/ld+json";
    schema.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: items.map((item, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: item.name,
        item: item.url,
      })),
    });
    document.head.appendChild(schema);

    return () => {
      if (schema.parentNode) {
        schema.parentNode.removeChild(schema);
      }
    };
  }, [items]);

  return null;
}

export function ArticleSchema({
  title,
  description,
  datePublished,
  dateModified,
  author,
  image,
}: {
  title: string;
  description: string;
  datePublished: string;
  dateModified: string;
  author: string;
  image: string;
}) {
  useEffect(() => {
    const schema = document.createElement("script");
    schema.type = "application/ld+json";
    schema.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      headline: title,
      description: description,
      image: image,
      datePublished: datePublished,
      dateModified: dateModified,
      author: {
        "@type": "Organization",
        name: author,
      },
    });
    document.head.appendChild(schema);

    return () => {
      if (schema.parentNode) {
        schema.parentNode.removeChild(schema);
      }
    };
  }, [title, description, datePublished, dateModified, author, image]);

  return null;
}
