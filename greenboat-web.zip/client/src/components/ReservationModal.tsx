import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { X, CheckCircle, Calendar, Clock, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { bookingSchema, type BookingData } from "../../../shared/schemas";

type Step = 1 | 2 | 3 | 4;

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormData {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  boatName: string;
  boatBrand: string;
  boatModel: string;
  boatCategory: "voilier" | "moteur" | "autre";
  boatLength: number;
  boatLengthAtWaterline: number;
  boatWidth: number;
  boatDraft: number;
  surface: number;
  portAddress: string;
  quai: string;
  emplacement: string;
  zoneId: number;
  reservationDate: string;
  startTime: string;
  endTime: string;
}

interface TimeSlot {
  id: number;
  startTime: string;
  endTime: string;
  available: boolean;
}

export function ReservationModal({ isOpen, onClose }: ReservationModalProps) {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [formData, setFormData] = useState<Partial<FormData>>({
    boatLength: 10,
    boatWidth: 3,
    surface: 30,
    boatCategory: "moteur",
    zoneId: 1,
  });

  // Calculer la superficie immergee avec formule affinee
  // Superficie = LWL × Tirant d'eau × (Largeur totale / Longueur hors tout)
  const lengthAtWaterline = formData.boatLengthAtWaterline || formData.boatLength || 0;
  const draft = formData.boatDraft || 0;
  const boatLength = formData.boatLength || 0;
  const boatWidth = formData.boatWidth || 0;
  
  let calculatedSurface = 0;
  if (boatLength > 0 && boatWidth > 0) {
    const widthCoefficient = boatWidth / boatLength;
    calculatedSurface = lengthAtWaterline * draft * widthCoefficient;
  } else {
    calculatedSurface = lengthAtWaterline * draft;
  }
  
  const estimatedPrice = calculatedSurface * 15; // 15€ par m²
  const [successData, setSuccessData] = useState<{
    quoteNumber: string;
    totalPrice: number;
  } | null>(null);
  const [boatSearching, setBoatSearching] = useState(false);
  const [boatBrands, setBoatBrands] = useState<string[]>([]);
  const [boatModels, setBoatModels] = useState<any[]>([]);


  // Charger les marques de bateaux au montage
  useEffect(() => {
    const loadBrands = async () => {
      try {
        const utils = trpc.useUtils();
        const result = await utils.booking.getBoatBrands.fetch();
        if (result.success && result.data) {
          setBoatBrands(result.data);
        }
      } catch (error) {
        console.error("Error loading boat brands:", error);
      }
    };
    loadBrands();
  }, []);

  // Charger les modèles quand la marque change
  useEffect(() => {
    if (formData.boatBrand) {
      const loadModels = async () => {
        try {
          const utils = trpc.useUtils();
        const result = await utils.booking.getBoatModelsByBrand.fetch({
          brand: formData.boatBrand!,
        });
          if (result.success && result.data) {
            setBoatModels(result.data);
          }
        } catch (error) {
          console.error("Error loading boat models:", error);
        }
      };
      loadModels();
    } else {
      setBoatModels([]);
    }
  }, [formData.boatBrand]);

    const handleSearchBoat = async () => {
    if (!formData.boatBrand || !formData.boatModel) {
      toast.error("Veuillez entrer la marque et le modele");
      return;
    }
    
    setBoatSearching(true);
    try {
      const utils = trpc.useUtils();
      const result = await utils.booking.searchBoatSpecs.fetch({
        brand: formData.boatBrand,
        model: formData.boatModel,
      });
      
      if (result.success && result.data) {
        setFormData(prev => ({
          ...prev,
          boatLength: parseFloat(String(result.data.lengthOverall)),
          boatLengthAtWaterline: parseFloat(String(result.data.lengthAtWaterline)),
          boatWidth: parseFloat(String(result.data.beam)),
          boatDraft: parseFloat(String(result.data.draft)),
          surface: parseFloat(String(result.data.surface)),
        }));
        toast.success("Donnees du bateau trouvees!");
      } else {
        toast.error("Bateau non trouve");
      }
    } catch (error) {
      toast.error("Erreur lors de la recherche");
    } finally {
      setBoatSearching(false);
    }
  };

  const { data: timeSlots, isLoading: timeSlotsLoading } =
    trpc.booking.getAvailableTimeSlots.useQuery(
      {
        date: formData.reservationDate ? new Date(formData.reservationDate) : new Date(),
      },
      { enabled: !!formData.reservationDate }
    );

  const createReservation = trpc.booking.create.useMutation({
    onSuccess: (data) => {
      setSuccessData(data);
      setCurrentStep(4);
      toast.success("Réservation créée avec succès !");
    },
    onError: (error) => {
      toast.error(`Erreur: ${error.message}`);
    },
  });

  const validateStep = async (step: Step): Promise<boolean> => {
    if (step === 1) {
      if (!formData.clientName || formData.clientName.trim().length < 2) {
        toast.error("Le nom est requis (minimum 2 caracteres)");
        return false;
      }
      if (!formData.clientEmail || formData.clientEmail.trim().length === 0) {
        toast.error("Veuillez entrer une adresse email valide");
        return false;
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.clientEmail)) {
        toast.error("Veuillez entrer une adresse email valide");
        return false;
      }
      if (!formData.clientPhone || formData.clientPhone.trim().length === 0) {
        toast.error("Veuillez entrer un numero de telephone francais valide (06/07...)");
        return false;
      }
      return true;
    } else if (step === 2) {
      if (!formData.boatBrand || formData.boatBrand.trim().length === 0) {
        toast.error("La marque du bateau est requise");
        return false;
      }
      if (!formData.boatModel || formData.boatModel.trim().length === 0) {
        toast.error("Le modele du bateau est requis");
        return false;
      }
      if (!formData.boatLength || formData.boatLength <= 0) {
        toast.error("La longueur du bateau doit etre superieure a 0");
        return false;
      }
      if (!formData.boatLengthAtWaterline || formData.boatLengthAtWaterline <= 0) {
        toast.error("La longueur a la flottaison doit etre superieure a 0");
        return false;
      }
      if (!formData.boatDraft || formData.boatDraft <= 0) {
        toast.error("Le tirant d'eau doit etre superieur a 0");
        return false;
      }
      if (!formData.portAddress || formData.portAddress.trim().length === 0) {
        toast.error("Le port/marina est requis");
        return false;
      }
      if (!formData.quai || formData.quai.trim().length === 0) {
        toast.error("Le quai est requis");
        return false;
      }
      if (!formData.emplacement || formData.emplacement.trim().length === 0) {
        toast.error("L'emplacement est requis");
        return false;
      }
      return true;
    } else if (step === 3) {
      if (!formData.reservationDate) {
        toast.error("Veuillez selectionner une date");
        return false;
      }
      if (!formData.startTime || !formData.endTime) {
        toast.error("Veuillez selectionner un horaire");
        return false;
      }
      return true;
    }
    return true;
  }

  const handleNext = async () => {
    if (currentStep < 4) {
      const isValid = await validateStep(currentStep);
      if (isValid) {
        setCurrentStep((currentStep + 1) as Step);
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep((currentStep - 1) as Step);
    }
  };

  const handleSubmit = async () => {
    try {
      const dateStr = formData.reservationDate || "";
      const dateObj = new Date(dateStr + "T00:00:00");

      const bookingData: BookingData = {
        clientName: formData.clientName || "",
        clientEmail: formData.clientEmail || "",
        clientPhone: formData.clientPhone || "",
        boatName: formData.boatName || "",
        boatBrand: formData.boatBrand || "",
        boatModel: formData.boatModel || "",
        boatCategory: formData.boatCategory || "moteur",
        boatLength: formData.boatLength || 0,
        boatLengthAtWaterline: formData.boatLengthAtWaterline || formData.boatLength || 0,
        boatWidth: formData.boatWidth || 0,
        boatDraft: formData.boatDraft || 0,
        surface: calculatedSurface || 0,
        portAddress: formData.portAddress || "",
        quai: formData.quai || "",
        emplacement: formData.emplacement || "",
        zoneId: formData.zoneId || 1,
        reservationDate: dateObj,
        startTime: formData.startTime || "",
        endTime: formData.endTime || "",
      };

      await bookingSchema.parseAsync(bookingData);
      await createReservation.mutateAsync(bookingData);
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de la validation");
    }
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split("T")[0];
  };

  const stepTitles: Record<Step, string> = {
    1: "Informations Personnelles",
    2: "Détails du Bateau",
    3: "Date et Horaire",
    4: "Réservation Confirmée",
  };

  const stepDescriptions: Record<Step, string> = {
    1: "Étape 1/3 - Vos coordonnées",
    2: "Étape 2/3 - Informations de votre bateau",
    3: "Étape 3/3 - Sélectionnez votre date et horaire",
    4: "Votre réservation a été confirmée",
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>{stepTitles[currentStep]}</CardTitle>
            <CardDescription>{stepDescriptions[currentStep]}</CardDescription>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </CardHeader>

        {/* Progress Bar */}
        <div className="px-6 mb-6">
          <div className="flex justify-between mb-4">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`flex items-center justify-center w-10 h-10 rounded-full font-bold ${
                  step === currentStep
                    ? "bg-blue-600 text-white"
                    : step < currentStep
                    ? "bg-green-600 text-white"
                    : "bg-gray-300 text-gray-600"
                }`}
              >
                {step < currentStep ? "✓" : step}
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            />
          </div>
        </div>

        <CardContent className="space-y-6">
          {/* Step 1: Client Info */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Nom complet *</Label>
                <Input
                  id="name"
                  placeholder="Jean Dupont"
                  value={formData.clientName || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, clientName: e.target.value })
                  }
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="jean@example.com"
                  value={formData.clientEmail || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, clientEmail: e.target.value })
                  }
                />
              </div>
              <div>
                <Label htmlFor="phone">Téléphone (06/07) *</Label>
                <Input
                  id="phone"
                  placeholder="06 12 34 56 78"
                  value={formData.clientPhone || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, clientPhone: e.target.value })
                  }
                />
              </div>
            </div>
          )}

          {/* Step 2: Boat Info */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="boatName">Nom du bateau</Label>
                <Input
                  id="boatName"
                  placeholder="Ex: Mon Bateau"
                  value={formData.boatName || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, boatName: e.target.value })
                  }
                />
              </div>
              <div>
                <Label htmlFor="brand">Marque du bateau *</Label>
                <Select
                  value={formData.boatBrand || ""}
                  onValueChange={(value) => {
                    setFormData({ ...formData, boatBrand: value, boatModel: "" });
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez une marque" />
                  </SelectTrigger>
                  <SelectContent>
                    {boatBrands.map((brand) => (
                      <SelectItem key={brand} value={brand}>
                        {brand}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="model">Modèle du bateau *</Label>
                <Select
                  value={formData.boatModel || ""}
                  onValueChange={(value) => {
                    const selectedModel = boatModels.find(m => m.model === value);
                    if (selectedModel) {
                      setFormData({
                        ...formData,
                        boatModel: value,
                        boatLength: parseFloat(selectedModel.loa),
                        boatLengthAtWaterline: parseFloat(selectedModel.loa),
                        boatWidth: parseFloat(selectedModel.beam),
                        boatDraft: parseFloat(selectedModel.draft),
                        surface: parseFloat(selectedModel.surface),
                      });
                    }
                  }}
                  disabled={!formData.boatBrand}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={formData.boatBrand ? "Sélectionnez un modèle" : "D'abord sélectionnez une marque"} />
                  </SelectTrigger>
                  <SelectContent>
                    {boatModels.map((model) => (
                      <SelectItem key={model.id} value={model.model}>
                        {model.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="category">Catégorie du bateau *</Label>
                <Select
                  value={formData.boatCategory || "moteur"}
                  onValueChange={(value) =>
                    setFormData({
                      ...formData,
                      boatCategory: value as "voilier" | "moteur" | "autre",
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="voilier">Voilier</SelectItem>
                    <SelectItem value="moteur">Moteur</SelectItem>
                    <SelectItem value="autre">Autre</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="length">Longueur hors tout (m) *</Label>
                <Input
                  id="length"
                  type="number"
                  placeholder="10"
                  value={formData.boatLength || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      boatLength: parseFloat(e.target.value),
                    })
                  }
                />
              </div>
              <div>
                <Label htmlFor="lengthAtWaterline">Longueur a la flottaison (m)</Label>
                <Input
                  id="lengthAtWaterline"
                  type="number"
                  placeholder="9.5"
                  value={formData.boatLengthAtWaterline || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      boatLengthAtWaterline: parseFloat(e.target.value),
                    })
                  }
                />
                <p className="text-sm text-gray-500 mt-1">Optionnel - utilisera la longueur hors tout si non rempli</p>
              </div>
              <div>
                <Label htmlFor="width">Largeur (m)</Label>
                <Input
                  id="width"
                  type="number"
                  placeholder="3"
                  value={formData.boatWidth || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      boatWidth: parseFloat(e.target.value),
                    })
                  }
                />
                <p className="text-sm text-gray-500 mt-1">Optionnel</p>
              </div>
              <div>
                <Label htmlFor="draft">Tirant d'eau (m) *</Label>
                <Input
                  id="draft"
                  type="number"
                  placeholder="2.0"
                  value={formData.boatDraft || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      boatDraft: parseFloat(e.target.value),
                    })
                  }
                />
              </div>
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-semibold">Superficie à nettoyer:</span>
                    <span className="font-bold text-blue-600">{calculatedSurface.toFixed(2)} m²</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">Tarif unitaire:</span>
                    <span>15€/m²</span>
                  </div>
                  <div className="border-t border-blue-200 pt-2 flex justify-between">
                    <span className="font-semibold text-lg">Estimation du devis:</span>
                    <span className="font-bold text-lg text-green-600">{estimatedPrice.toFixed(2)}€</span>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="surface">Surface (m²) *</Label>
                <Input
                  id="surface"
                  type="number"
                  placeholder="30"
                  value={calculatedSurface.toFixed(2)}
                  disabled
                  className="bg-gray-100 cursor-not-allowed"
                />
                <p className="text-sm text-gray-500 mt-1">Calculée automatiquement (longueur flottaison × tirant d'eau)</p>
              </div>
              <div>
                <Label htmlFor="portAddress">Port/Marina *</Label>
                <Input
                  id="portAddress"
                  placeholder="Ex: Port d'Arcachon"
                  value={formData.portAddress || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      portAddress: e.target.value,
                    })
                  }
                />
              </div>
              <div>
                <Label htmlFor="quai">Quai *</Label>
                <Input
                  id="quai"
                  placeholder="Ex: Quai A"
                  value={formData.quai || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, quai: e.target.value })
                  }
                />
              </div>
              <div>
                <Label htmlFor="emplacement">Emplacement *</Label>
                <Input
                  id="emplacement"
                  placeholder="Ex: Ponton 5"
                  value={formData.emplacement || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      emplacement: e.target.value,
                    })
                  }
                />
              </div>
            </div>
          )}

          {/* Step 3: Date and Time */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="date">Date de réservation *</Label>
                <Input
                  id="date"
                  type="date"
                  min={getMinDate()}
                  value={formData.reservationDate || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      reservationDate: e.target.value,
                    })
                  }
                />
              </div>

              {formData.reservationDate && (
                <>
                  <div>
                    <Label>Horaires disponibles *</Label>
                    {timeSlotsLoading ? (
                      <div className="text-center py-4">Chargement...</div>
                    ) : timeSlots && timeSlots.length > 0 ? (
                      <div className="grid grid-cols-2 gap-2">
                        {timeSlots.map((slot: TimeSlot) => (
                          <button
                            key={slot.id}
                            onClick={() => {
                              setFormData({
                                ...formData,
                                startTime: slot.startTime,
                                endTime: slot.endTime,
                              });
                            }}
                            disabled={!slot.available}
                            className={`p-3 rounded-lg border-2 transition ${
                              formData.startTime === slot.startTime
                                ? "border-blue-600 bg-blue-50"
                                : slot.available
                                ? "border-gray-200 hover:border-blue-600"
                                : "border-gray-200 bg-gray-50 opacity-50 cursor-not-allowed"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <Clock size={16} />
                              <span className="text-sm font-medium">
                                {slot.startTime} - {slot.endTime}
                              </span>
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4 text-gray-500">
                        Aucun créneau disponible pour cette date
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Step 4: Confirmation */}
          {currentStep === 4 && successData && (
            <div className="text-center space-y-4">
              <CheckCircle className="mx-auto text-green-600" size={64} />
              <h3 className="text-2xl font-bold text-gray-900">
                Réservation Confirmée !
              </h3>
              <div className="bg-blue-50 p-6 rounded-lg space-y-2">
                <p className="text-gray-700">
                  <strong>Numéro de devis :</strong> {successData.quoteNumber}
                </p>
                <p className="text-gray-700">
                  <strong>Montant total :</strong>{" "}
                  {successData.totalPrice.toFixed(2)}€
                </p>
              </div>
              <p className="text-gray-600">
                Un email de confirmation a été envoyé à {formData.clientEmail}
              </p>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between gap-4 pt-6">
            {currentStep > 1 && currentStep < 4 && (
              <Button variant="outline" onClick={handlePrevious}>
                Précédent
              </Button>
            )}
            {currentStep < 3 && (
              <Button
                onClick={handleNext}
                className="ml-auto bg-blue-600 hover:bg-blue-700 text-white"
              >
                Suivant
              </Button>
            )}
            {currentStep === 3 && (
              <Button
                onClick={handleSubmit}
                disabled={createReservation.isPending}
                className="ml-auto bg-blue-600 hover:bg-blue-700 text-white"
              >
                {createReservation.isPending ? "Création..." : "Confirmer la réservation"}
              </Button>
            )}
            {currentStep === 4 && (
              <Button
                onClick={onClose}
                className="ml-auto bg-blue-600 hover:bg-blue-700 text-white"
              >
                Fermer
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
