/**
 * Configuration des produits Stripe pour Green Boat
 * Les prix sont définis en centimes (ex: 5000 = 50€)
 */

export const STRIPE_PRODUCTS = {
  BOAT_CLEANING: {
    name: "Nettoyage Écologique de Carène",
    description: "Service professionnel de nettoyage écologique - 2 heures d'intervention",
  },
};

/**
 * Calcul du montant Stripe basé sur le prix total de la réservation
 * @param totalPrice Prix en euros
 * @returns Montant en centimes pour Stripe
 */
export function calculateStripeAmount(totalPrice: number): number {
  return Math.round(totalPrice * 100);
}
