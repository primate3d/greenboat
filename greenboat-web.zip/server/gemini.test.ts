import { describe, it, expect } from "vitest";
import { invokeLLM } from "./_core/llm";

describe("Gemini Integration", () => {
  it("should validate Gemini API key by making a simple request", async () => {
    try {
      // Test simple LLM call to validate API key
      const response = await invokeLLM({
        messages: [
          {
            role: "user",
            content: "Say 'Gemini API is working' in one sentence.",
          },
        ],
      });

      // Check that we got a valid response
      expect(response).toBeDefined();
      expect(response.choices).toBeDefined();
      expect(response.choices.length).toBeGreaterThan(0);
      expect(response.choices[0].message).toBeDefined();
      expect(response.choices[0].message.content).toBeDefined();
      expect(typeof response.choices[0].message.content).toBe("string");

      console.log("✓ Gemini API Key validated successfully");
      console.log("Response:", response.choices[0].message.content);
    } catch (error: any) {
      console.error("✗ Gemini API validation failed:", error.message);
      throw new Error(`Gemini API validation failed: ${error.message}`);
    }
  });
});
