import { getDb } from "./db";
import { reservations } from "../drizzle/schema";
import { and, eq, gte, lt } from "drizzle-orm";

interface TimeSlot {
  id: number;
  startTime: string;
  endTime: string;
  available: boolean;
}

/**
 * Convertir une heure au format HH:MM en minutes depuis minuit
 */
function timeToMinutes(time: string): number {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
}

/**
 * Convertir des minutes depuis minuit au format HH:MM
 */
function minutesToTime(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

/**
 * Générer tous les créneaux horaires disponibles pour une date
 * En tenant compte des réservations existantes et du temps d'intervention de 2 heures
 */
export async function generateAvailableTimeSlots(date: Date): Promise<TimeSlot[]> {
  const db = await getDb();
  if (!db) return [];

  // Récupérer toutes les réservations pour cette date
  const dateStart = new Date(date);
  dateStart.setHours(0, 0, 0, 0);
  
  const dateEnd = new Date(date);
  dateEnd.setHours(23, 59, 59, 999);

  const existingReservations = await db
    .select()
    .from(reservations)
    .where(
      and(
        gte(reservations.reservationDate, dateStart),
        lt(reservations.reservationDate, dateEnd),
        eq(reservations.status, "pending")
      )
    );

  // Créer une liste des créneaux occupés (avec 2 heures de durée)
  const occupiedSlots: Array<{ start: number; end: number }> = [];
  
  for (const reservation of existingReservations) {
    const startMinutes = timeToMinutes(reservation.startTime);
    const endMinutes = startMinutes + 120; // 2 heures = 120 minutes
    occupiedSlots.push({ start: startMinutes, end: endMinutes });
  }

  // Générer tous les créneaux possibles (toutes les heures de 8h à 18h)
  const allSlots: TimeSlot[] = [];
  let slotId = 1;

  for (let hour = 8; hour < 18; hour++) {
    const startMinutes = hour * 60;
    const endMinutes = startMinutes + 120; // 2 heures
    const startTime = minutesToTime(startMinutes);
    const endTime = minutesToTime(endMinutes);

    // Vérifier si ce créneau chevauche un créneau occupé
    const isOccupied = occupiedSlots.some(
      (slot) => startMinutes < slot.end && endMinutes > slot.start
    );

    allSlots.push({
      id: slotId++,
      startTime,
      endTime,
      available: !isOccupied,
    });
  }

  return allSlots;
}

/**
 * Vérifier si un créneau horaire est disponible
 */
export async function isTimeSlotAvailable(
  date: Date,
  startTime: string,
  endTime: string
): Promise<boolean> {
  const slots = await generateAvailableTimeSlots(date);
  return slots.some(
    (slot) =>
      slot.startTime === startTime && slot.endTime === endTime && slot.available
  );
}
