import { invokeLLM } from "./_core/llm";
import { formatPrice, formatDateFR } from "../shared/utils";

interface ReservationEmailData {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  quoteNumber: string;
  boatName?: string;
  boatCategory: "voilier" | "moteur" | "autre";
  boatLength: number;
  surface: number;
  portAddress: string;
  quai: string;
  emplacement: string;
  reservationDate: Date;
  startTime: string;
  endTime: string;
  totalPrice: number;
}

/**
 * Générer un email détaillé pour le client avec Gemini
 */
export async function generateClientEmailWithGemini(
  data: ReservationEmailData
): Promise<string> {
  const formattedDate = formatDateFR(data.reservationDate);
  const formattedPrice = formatPrice(data.totalPrice);
  const boatCategoryLabel =
    data.boatCategory === "voilier"
      ? "Voilier"
      : data.boatCategory === "moteur"
      ? "Moteur"
      : "Autre";

  const prompt = `Tu es un rédacteur professionnel pour Green Boat, une entreprise de nettoyage écologique de carènes.

Génère un email HTML détaillé et professionnel de confirmation de réservation pour le client avec les informations suivantes:

**Informations du client:**
- Nom: ${data.clientName}
- Email: ${data.clientEmail}
- Téléphone: ${data.clientPhone}

**Informations de la réservation:**
- Numéro de devis: ${data.quoteNumber}
- Date d'intervention: ${formattedDate}
- Horaire: ${data.startTime} - ${data.endTime}
- Montant total: ${formattedPrice}

**Informations du bateau:**
- Nom: ${data.boatName || "Non spécifié"}
- Catégorie: ${boatCategoryLabel}
- Longueur: ${(data.boatLength / 10).toFixed(1)} m
- Surface: ${(data.surface / 100).toFixed(2)} m²

**Localisation:**
- Port/Marina: ${data.portAddress}
- Quai: ${data.quai}
- Emplacement: ${data.emplacement}

Génère un email HTML complet avec:
1. Un en-tête professionnel avec le logo Green Boat 🚤
2. Une salutation personnalisée
3. Un résumé de la réservation en sections claires
4. Les détails du bateau et de l'intervention
5. Les informations de paiement
6. Les prochaines étapes
7. Un footer avec contact et mentions légales

L'email doit être:
- Professionnel et courtois
- Structuré avec des sections claires
- Optimisé pour la lecture sur mobile
- Incluant des emojis pertinents
- Avec des couleurs vertes et bleues (codes: #0fb812, #1bb61e, #24cc56, #0066cc)

Retourne UNIQUEMENT le code HTML complet, sans explications.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const emailContent = response.choices[0].message.content;
    
    // Vérifier que c'est une string
    if (typeof emailContent !== 'string') {
      throw new Error('Invalid response from Gemini API');
    }

    // Nettoyer le contenu si nécessaire (enlever les balises markdown)
    return emailContent
      .replace(/```html\n?/g, "")
      .replace(/```\n?/g, "")
      .trim();
  } catch (error) {
    console.error("[Gemini] Failed to generate client email:", error);
    throw error;
  }
}

/**
 * Générer un email détaillé pour le propriétaire avec Gemini
 */
export async function generateOwnerEmailWithGemini(
  data: ReservationEmailData
): Promise<string> {
  const formattedDate = formatDateFR(data.reservationDate);
  const formattedPrice = formatPrice(data.totalPrice);
  const boatCategoryLabel =
    data.boatCategory === "voilier"
      ? "Voilier"
      : data.boatCategory === "moteur"
      ? "Moteur"
      : "Autre";

  const prompt = `Tu es un rédacteur professionnel pour Green Boat, une entreprise de nettoyage écologique de carènes.

Génère un email HTML détaillé et professionnel pour le propriétaire/manager avec les informations de la nouvelle réservation:

**Informations du client:**
- Nom: ${data.clientName}
- Email: ${data.clientEmail}
- Téléphone: ${data.clientPhone}

**Informations de la réservation:**
- Numéro de devis: ${data.quoteNumber}
- Date d'intervention: ${formattedDate}
- Horaire: ${data.startTime} - ${data.endTime}
- Montant total: ${formattedPrice}

**Informations du bateau:**
- Nom: ${data.boatName || "Non spécifié"}
- Catégorie: ${boatCategoryLabel}
- Longueur: ${(data.boatLength / 10).toFixed(1)} m
- Surface: ${(data.surface / 100).toFixed(2)} m²

**Localisation:**
- Port/Marina: ${data.portAddress}
- Quai: ${data.quai}
- Emplacement: ${data.emplacement}

Génère un email HTML complet pour le propriétaire avec:
1. Un en-tête professionnel avec le logo Green Boat 🚤
2. Une alerte claire: "NOUVELLE RÉSERVATION"
3. Les détails complets du client et du bateau
4. Les détails de l'intervention (date, heure, localisation)
5. Le montant de la réservation
6. Les actions à prendre (confirmation, préparation, etc.)
7. Un footer avec les coordonnées de contact

L'email doit être:
- Clair et facile à scanner
- Avec des sections bien organisées
- Incluant des emojis pertinents
- Avec des couleurs vertes et bleues (codes: #0fb812, #1bb61e, #24cc56, #0066cc)
- Prêt pour impression si nécessaire

Retourne UNIQUEMENT le code HTML complet, sans explications.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const emailContent = response.choices[0].message.content;
    
    // Vérifier que c'est une string
    if (typeof emailContent !== 'string') {
      throw new Error('Invalid response from Gemini API');
    }

    // Nettoyer le contenu si nécessaire (enlever les balises markdown)
    return emailContent
      .replace(/```html\n?/g, "")
      .replace(/```\n?/g, "")
      .trim();
  } catch (error) {
    console.error("[Gemini] Failed to generate owner email:", error);
    throw error;
  }
}

/**
 * Générer un email de validation avec Gemini
 */
export async function generateValidationEmailWithGemini(
  data: ReservationEmailData,
  validationLink: string
): Promise<string> {
  const formattedDate = formatDateFR(data.reservationDate);
  const formattedPrice = formatPrice(data.totalPrice);
  const boatCategoryLabel =
    data.boatCategory === "voilier"
      ? "Voilier"
      : data.boatCategory === "moteur"
      ? "Moteur"
      : "Autre";

  const prompt = `Tu es un rédacteur professionnel pour Green Boat, une entreprise de nettoyage écologique de carènes.

Génère un email HTML détaillé et professionnel de validation de réservation pour le client avec les informations suivantes:

**Informations du client:**
- Nom: ${data.clientName}
- Email: ${data.clientEmail}

**Informations de la réservation:**
- Numéro de devis: ${data.quoteNumber}
- Date d'intervention: ${formattedDate}
- Horaire: ${data.startTime} - ${data.endTime}
- Montant total: ${formattedPrice}

**Lien de validation:**
${validationLink}

**Informations du bateau:**
- Catégorie: ${boatCategoryLabel}
- Longueur: ${(data.boatLength / 10).toFixed(1)} m
- Surface: ${(data.surface / 100).toFixed(2)} m²

**Localisation:**
- Port/Marina: ${data.portAddress}
- Quai: ${data.quai}
- Emplacement: ${data.emplacement}

Génère un email HTML complet avec:
1. Un en-tête professionnel avec le logo Green Boat 🚤
2. Une salutation personnalisée
3. Un appel à l'action clair: "Valider ma réservation"
4. Un bouton CTA bleu avec le lien de validation
5. Une alerte: "Ce lien expire dans 24 heures"
6. Un résumé de la réservation
7. Les détails du bateau et de l'intervention
8. Les prochaines étapes après validation
9. Un footer avec contact

L'email doit être:
- Professionnel et persuasif
- Avec un CTA clair et visible
- Optimisé pour mobile
- Incluant des emojis pertinents
- Avec des couleurs vertes et bleues (codes: #0fb812, #1bb61e, #24cc56, #0066cc)

Retourne UNIQUEMENT le code HTML complet, sans explications.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const emailContent = response.choices[0].message.content;
    
    // Vérifier que c'est une string
    if (typeof emailContent !== 'string') {
      throw new Error('Invalid response from Gemini API');
    }

    // Nettoyer le contenu si nécessaire (enlever les balises markdown)
    return emailContent
      .replace(/```html\n?/g, "")
      .replace(/```\n?/g, "")
      .trim();
  } catch (error) {
    console.error("[Gemini] Failed to generate validation email:", error);
    throw error;
  }
}
