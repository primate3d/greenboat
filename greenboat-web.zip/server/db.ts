import { and, desc, eq, gte, lte, ne, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  boatModels,
  InsertReservation,
  InsertAvailableTimeSlot,
  users,
  reservations,
  zones,
  availableTimeSlots,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Récupérer toutes les zones avec leurs créneaux horaires
 */
export async function getZonesWithTimeSlots() {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(zones);
  return result;
}

/**
 * Récupérer les créneaux horaires disponibles pour une zone et un jour spécifique
 */
export async function getAvailableTimeSlotsByZoneAndDay(zoneId: number, dayOfWeek: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select()
    .from(availableTimeSlots)
    .where(
      and(
        eq(availableTimeSlots.zoneId, zoneId),
        eq(availableTimeSlots.dayOfWeek, dayOfWeek)
      )
    );
  
  return result;
}

/**
 * Créer une nouvelle réservation
 */
export async function createReservation(data: InsertReservation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(reservations).values({
    quoteNumber: data.quoteNumber,
    clientName: data.clientName,
    clientEmail: data.clientEmail,
    clientPhone: data.clientPhone,
    boatName: data.boatName || null,
    boatCategory: data.boatCategory,
    boatLength: data.boatLength,
    surface: data.surface,
    portAddress: data.portAddress,
    quai: data.quai,
    emplacement: data.emplacement,
    zoneId: data.zoneId,
    reservationDate: data.reservationDate,
    startTime: data.startTime,
    endTime: data.endTime,
    basePrice: data.basePrice,
    totalPrice: data.totalPrice,
    status: data.status || "pending",
    notes: data.notes || "",
  });
  
  return result;
}

/**
 * Récupérer une réservation par son ID
 */
export async function getReservationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(reservations)
    .where(eq(reservations.id, id))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Récupérer une réservation par son numéro de devis
 */
export async function getReservationByQuoteNumber(quoteNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(reservations)
    .where(eq(reservations.quoteNumber, quoteNumber))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Récupérer toutes les réservations avec filtrage optionnel
 */
export async function getReservations(filters?: {
  status?: string;
  zoneId?: number;
  startDate?: Date;
  endDate?: Date;
}) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(reservations) as any;
  
  if (filters?.status) {
    query = query.where(eq(reservations.status, filters.status as any));
  }
  if (filters?.zoneId) {
    query = query.where(eq(reservations.zoneId, filters.zoneId));
  }
  if (filters?.startDate) {
    query = query.where(gte(reservations.reservationDate, filters.startDate));
  }
  if (filters?.endDate) {
    query = query.where(lte(reservations.reservationDate, filters.endDate));
  }
  
  return query.orderBy(desc(reservations.createdAt));
}

/**
 * Mettre à jour une réservation
 */
export async function updateReservation(id: number, data: Partial<InsertReservation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: any = { ...data, updatedAt: new Date() };
  
  await db
    .update(reservations)
    .set(updateData)
    .where(eq(reservations.id, id));
}

/**
 * Mettre à jour le statut d'une réservation
 */
export async function updateReservationStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(reservations)
    .set({ status: status as any, updatedAt: new Date() })
    .where(eq(reservations.id, id));
}

/**
 * Compter les réservations pour un créneau horaire spécifique
 */
export async function countReservationsForTimeSlot(
  zoneId: number,
  reservationDate: Date,
  startTime: string
) {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db
    .select({ count: sql`COUNT(*)` })
    .from(reservations)
    .where(
      and(
        eq(reservations.zoneId, zoneId),
        eq(reservations.reservationDate, reservationDate),
        eq(reservations.startTime, startTime),
        ne(reservations.status, "cancelled")
      )
    );
  
  return result[0]?.count as number || 0;
}

/**
 * Rechercher un modèle de bateau par marque et modèle
 */
export async function searchBoatModel(brand: string, model: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(boatModels)
    .where(
      and(
        eq(boatModels.brand, brand),
        eq(boatModels.model, model)
      )
    )
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Récupérer tous les modèles de bateau pour une marque donnée
 */
export async function getBoatModelsByBrand(brand: string) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select()
    .from(boatModels)
    .where(eq(boatModels.brand, brand))
    .orderBy(boatModels.model);
  
  return result;
}

/**
 * Récupérer toutes les marques uniques de bateaux
 */
export async function getAllBoatBrands() {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .selectDistinct({ brand: boatModels.brand })
    .from(boatModels)
    .orderBy(boatModels.brand);
  
  return result.map(r => r.brand);
}
