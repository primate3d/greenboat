import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Contexte public pour les tests
const publicContext: TrpcContext = {
  user: null,
  req: {
    protocol: "https",
    headers: {},
  } as TrpcContext["req"],
  res: {
    clearCookie: () => {},
  } as TrpcContext["res"],
};

describe("Booking Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(publicContext);
  });

  describe("getAvailableTimeSlots", () => {
    it("should return time slots for a valid date", async () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);

      const slots = await caller.booking.getAvailableTimeSlots({
        date: tomorrow,
      });

      expect(Array.isArray(slots)).toBe(true);
      // Slots might be empty on certain days, but should be an array
      if (slots.length > 0) {
        expect(slots[0]).toHaveProperty("startTime");
        expect(slots[0]).toHaveProperty("endTime");
        expect(slots[0]).toHaveProperty("available");
      }
    });
  });

  describe("create reservation", () => {
    it("should validate required fields", async () => {
      try {
        await caller.booking.create({
          clientName: "",
          clientEmail: "test@example.com",
          clientPhone: "0612345678",
          boatName: "Test Boat",
          boatCategory: "moteur",
          boatLength: 10,
          surface: 25,
          portAddress: "Port Test",
          quai: "Quai A",
          emplacement: "Ponton 1",
          zoneId: 1,
          reservationDate: new Date(),
          startTime: "08:00",
          endTime: "10:00",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("nom");
      }
    });

    it("should validate phone number format", async () => {
      try {
        await caller.booking.create({
          clientName: "Test User",
          clientEmail: "test@example.com",
          clientPhone: "invalid",
          boatName: "Test Boat",
          boatCategory: "moteur",
          boatLength: 10,
          surface: 25,
          portAddress: "Port Test",
          quai: "Quai A",
          emplacement: "Ponton 1",
          zoneId: 1,
          reservationDate: new Date(),
          startTime: "08:00",
          endTime: "10:00",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("téléphone");
      }
    });

    it("should validate email format", async () => {
      try {
        await caller.booking.create({
          clientName: "Test User",
          clientEmail: "invalid-email",
          clientPhone: "0612345678",
          boatName: "Test Boat",
          boatCategory: "moteur",
          boatLength: 10,
          surface: 25,
          portAddress: "Port Test",
          quai: "Quai A",
          emplacement: "Ponton 1",
          zoneId: 1,
          reservationDate: new Date(),
          startTime: "08:00",
          endTime: "10:00",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("email");
      }
    });

    it("should validate boat dimensions", async () => {
      try {
        await caller.booking.create({
          clientName: "Test User",
          clientEmail: "test@example.com",
          clientPhone: "0612345678",
          boatName: "Test Boat",
          boatCategory: "moteur",
          boatLength: 0.5, // Too small
          surface: 25,
          portAddress: "Port Test",
          quai: "Quai A",
          emplacement: "Ponton 1",
          zoneId: 1,
          reservationDate: new Date(),
          startTime: "08:00",
          endTime: "10:00",
        } as any);
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("longueur");
      }
    });
  });

  describe("getByQuoteNumber", () => {
    it("should return null for non-existent quote number", async () => {
      const reservation = await caller.booking.getByQuoteNumber({
        quoteNumber: "GB-2026-00000",
      });
      expect(reservation).toBeUndefined();
    });
  });
});
