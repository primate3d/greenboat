import axios from "axios";

// Vérifier que les clés Brevo sont configurées
const BREVO_API_KEY = process.env.BREVO_API_KEY;
const BREVO_FROM_EMAIL = process.env.BREVO_FROM_EMAIL;

interface ReservationEmailData {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  quoteNumber: string;
  boatName?: string;
  boatCategory: "voilier" | "moteur" | "autre";
  boatLength: number;
  surface: number;
  portAddress: string;
  quai: string;
  emplacement: string;
  reservationDate: Date;
  startTime: string;
  endTime: string;
  totalPrice: number;
}

/**
 * Formater une date en français
 */
function formatDateFR(date: Date): string {
  const options: Intl.DateTimeFormatOptions = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return date.toLocaleDateString("fr-FR", options);
}

/**
 * Formater un prix en euros
 */
function formatPrice(price: number): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
  }).format(price);
}

/**
 * Générer le contenu HTML de l'email de confirmation pour le client
 */
function generateClientEmailHTML(data: ReservationEmailData): string {
  const formattedDate = formatDateFR(data.reservationDate);
  const formattedPrice = formatPrice(data.totalPrice);
  const boatCategoryLabel =
    data.boatCategory === "voilier"
      ? "Voilier"
      : data.boatCategory === "moteur"
      ? "Moteur"
      : "Autre";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
          .header { background: linear-gradient(135deg, #0fb812 0%, #1bb61e 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
          .header h1 { margin: 0; font-size: 28px; }
          .header p { margin: 10px 0 0 0; opacity: 0.9; }
          .content { padding: 30px; }
          .section { margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #0fb812; border-radius: 4px; }
          .section h3 { margin-top: 0; color: #0fb812; font-size: 18px; }
          .section p { margin: 8px 0; }
          .quote-number { font-size: 32px; font-weight: bold; color: #0fb812; text-align: center; padding: 20px; background-color: #f0f9f0; border-radius: 4px; }
          .price { font-size: 24px; font-weight: bold; color: #0fb812; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px; }
          .button { display: inline-block; background-color: #0fb812; color: white; padding: 12px 30px; text-decoration: none; border-radius: 4px; margin-top: 20px; }
          .info-row { display: flex; justify-content: space-between; margin: 8px 0; }
          .info-label { font-weight: bold; color: #0fb812; }
          .info-value { color: #333; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚤 Green Boat</h1>
            <p>Nettoyage Écologique de Carènes</p>
          </div>

          <div class="content">
            <p>Bonjour <strong>${data.clientName}</strong>,</p>
            <p>Merci de votre réservation ! Nous avons bien reçu votre demande de nettoyage écologique de carène. Voici les détails complets de votre réservation.</p>

            <div class="section">
              <h3>📋 Numéro de Devis</h3>
              <div class="quote-number">${data.quoteNumber}</div>
            </div>

            <div class="section">
              <h3>👤 Vos Informations</h3>
              <div class="info-row">
                <span class="info-label">Nom:</span>
                <span class="info-value">${data.clientName}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Email:</span>
                <span class="info-value">${data.clientEmail}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Téléphone:</span>
                <span class="info-value">${data.clientPhone}</span>
              </div>
            </div>

            <div class="section">
              <h3>🚤 Informations du Bateau</h3>
              <div class="info-row">
                <span class="info-label">Nom du bateau:</span>
                <span class="info-value">${data.boatName || "Non spécifié"}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Type:</span>
                <span class="info-value">${boatCategoryLabel}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Longueur:</span>
                <span class="info-value">${(data.boatLength / 10).toFixed(1)} mètres</span>
              </div>
              <div class="info-row">
                <span class="info-label">Surface de coque:</span>
                <span class="info-value">${(data.surface / 100).toFixed(2)} m²</span>
              </div>
            </div>

            <div class="section">
              <h3>📍 Localisation</h3>
              <div class="info-row">
                <span class="info-label">Port/Marina:</span>
                <span class="info-value">${data.portAddress}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Quai:</span>
                <span class="info-value">${data.quai}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Emplacement:</span>
                <span class="info-value">${data.emplacement}</span>
              </div>
            </div>

            <div class="section">
              <h3>📅 Date et Horaire d'Intervention</h3>
              <div class="info-row">
                <span class="info-label">Date:</span>
                <span class="info-value">${formattedDate}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Horaire:</span>
                <span class="info-value">${data.startTime} - ${data.endTime}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Durée:</span>
                <span class="info-value">2 heures</span>
              </div>
            </div>

            <div class="section">
              <h3>💰 Tarification</h3>
              <p style="text-align: center; font-size: 18px;">
                <strong>Montant Total: <span class="price">${formattedPrice}</span></strong>
              </p>
            </div>

            <div class="section">
              <h3>✅ Prochaines Étapes</h3>
              <p>1. Nous allons valider votre réservation dans les 24 heures</p>
              <p>2. Vous recevrez une confirmation définitive par email</p>
              <p>3. Notre équipe interviendra à la date et l'heure convenues</p>
              <p>4. Vous recevrez une facture après le nettoyage</p>
            </div>

            <div class="section">
              <h3>ℹ️ À Propos de Notre Service</h3>
              <p>Green Boat utilise la technologie Keelcrab pour un nettoyage écologique et sans mise à sec de votre bateau. Notre service est :</p>
              <p>✓ Écologique - Pas de produits chimiques agressifs<br>
              ✓ Professionnel - Équipe certifiée<br>
              ✓ Rapide - Intervention de 2 heures<br>
              ✓ Sûr - Bateau reste à flot</p>
            </div>

            <div style="text-align: center; margin-top: 30px;">
              <p><strong>Des questions ?</strong></p>
              <p>Contactez-nous à <strong>yanntejou@ik.me</strong> ou appelez-nous</p>
            </div>
          </div>

          <div class="footer">
            <p>&copy; 2026 Green Boat - Nettoyage Écologique de Carènes</p>
            <p>Tous droits réservés | <a href="#" style="color: #0fb812; text-decoration: none;">Mentions Légales</a></p>
          </div>
        </div>
      </body>
    </html>
  `;
}

/**
 * Générer le contenu HTML de l'email de notification pour le propriétaire
 */
function generateOwnerEmailHTML(data: ReservationEmailData): string {
  const formattedDate = formatDateFR(data.reservationDate);
  const formattedPrice = formatPrice(data.totalPrice);
  const boatCategoryLabel =
    data.boatCategory === "voilier"
      ? "Voilier"
      : data.boatCategory === "moteur"
      ? "Moteur"
      : "Autre";

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
          .header { background: linear-gradient(135deg, #0fb812 0%, #1bb61e 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
          .header h1 { margin: 0; font-size: 28px; }
          .content { padding: 30px; }
          .section { margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #0fb812; border-radius: 4px; }
          .section h3 { margin-top: 0; color: #0fb812; font-size: 18px; }
          .alert { background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; border-radius: 4px; margin: 20px 0; }
          .alert h3 { color: #856404; margin-top: 0; }
          .info-row { display: flex; justify-content: space-between; margin: 8px 0; }
          .info-label { font-weight: bold; color: #0fb812; }
          .info-value { color: #333; }
          .quote-number { font-size: 24px; font-weight: bold; color: #0fb812; }
          .price { font-size: 20px; font-weight: bold; color: #0fb812; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚤 Green Boat - Nouvelle Réservation</h1>
          </div>

          <div class="content">
            <div class="alert">
              <h3>⚠️ Nouvelle Demande de Réservation</h3>
              <p>Une nouvelle réservation a été reçue et nécessite votre attention.</p>
            </div>

            <div class="section">
              <h3>📋 Numéro de Devis</h3>
              <p class="quote-number">${data.quoteNumber}</p>
            </div>

            <div class="section">
              <h3>👤 Informations du Client</h3>
              <div class="info-row">
                <span class="info-label">Nom:</span>
                <span class="info-value">${data.clientName}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Email:</span>
                <span class="info-value">${data.clientEmail}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Téléphone:</span>
                <span class="info-value">${data.clientPhone}</span>
              </div>
            </div>

            <div class="section">
              <h3>🚤 Détails du Bateau</h3>
              <div class="info-row">
                <span class="info-label">Nom:</span>
                <span class="info-value">${data.boatName || "Non spécifié"}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Type:</span>
                <span class="info-value">${boatCategoryLabel}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Longueur:</span>
                <span class="info-value">${(data.boatLength / 10).toFixed(1)} m</span>
              </div>
              <div class="info-row">
                <span class="info-label">Surface:</span>
                <span class="info-value">${(data.surface / 100).toFixed(2)} m²</span>
              </div>
            </div>

            <div class="section">
              <h3>📍 Localisation</h3>
              <div class="info-row">
                <span class="info-label">Port:</span>
                <span class="info-value">${data.portAddress}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Quai:</span>
                <span class="info-value">${data.quai}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Emplacement:</span>
                <span class="info-value">${data.emplacement}</span>
              </div>
            </div>

            <div class="section">
              <h3>📅 Intervention Prévue</h3>
              <div class="info-row">
                <span class="info-label">Date:</span>
                <span class="info-value">${formattedDate}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Horaire:</span>
                <span class="info-value">${data.startTime} - ${data.endTime}</span>
              </div>
            </div>

            <div class="section">
              <h3>💰 Montant de la Réservation</h3>
              <p style="text-align: center; font-size: 18px;">
                <strong><span class="price">${formattedPrice}</span></strong>
              </p>
            </div>

            <div class="section">
              <h3>✅ Actions Recommandées</h3>
              <p>1. Vérifier la disponibilité de l'équipe pour la date demandée</p>
              <p>2. Confirmer la réservation auprès du client</p>
              <p>3. Préparer l'équipe et le matériel Keelcrab</p>
              <p>4. Envoyer les détails finaux au client</p>
            </div>
          </div>

          <div class="footer">
            <p>&copy; 2026 Green Boat - Système de Gestion des Réservations</p>
          </div>
        </div>
      </body>
    </html>
  `;
}

/**
 * Envoyer un email de confirmation au client
 */
export async function sendClientEmail(
  data: ReservationEmailData
): Promise<void> {
  try {
    console.log("[Email] Sending client email to:", data.clientEmail);

    const htmlContent = generateClientEmailHTML(data);

    if (BREVO_API_KEY && BREVO_FROM_EMAIL) {
      const emailPayload = {
        sender: {
          name: "Green Boat",
          email: BREVO_FROM_EMAIL,
        },
        to: [
          {
            email: data.clientEmail,
            name: data.clientName,
          },
        ],
        subject: `Confirmation de réservation - ${data.quoteNumber}`,
        htmlContent,
      };

      const response = await axios.post(
        "https://api.brevo.com/v3/smtp/email",
        emailPayload,
        {
          headers: {
            "api-key": BREVO_API_KEY,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("[Email] Client email sent successfully", {
        messageId: response.data.messageId,
      });
    } else {
      console.log("[Email] Brevo not configured. Email logged to console.");
    }
  } catch (error) {
    console.error("[Email] Failed to send client email:", error);
    throw error;
  }
}

/**
 * Envoyer un email de notification au propriétaire
 */
export async function sendOwnerEmail(
  data: ReservationEmailData,
  ownerEmail: string
): Promise<void> {
  try {
    console.log("[Email] Sending owner email to:", ownerEmail);

    const htmlContent = generateOwnerEmailHTML(data);

    if (BREVO_API_KEY && BREVO_FROM_EMAIL) {
      const emailPayload = {
        sender: {
          name: "Green Boat",
          email: BREVO_FROM_EMAIL,
        },
        to: [
          {
            email: ownerEmail,
            name: "Green Boat Manager",
          },
        ],
        subject: `Nouvelle Réservation - ${data.quoteNumber}`,
        htmlContent,
      };

      const response = await axios.post(
        "https://api.brevo.com/v3/smtp/email",
        emailPayload,
        {
          headers: {
            "api-key": BREVO_API_KEY,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("[Email] Owner email sent successfully", {
        messageId: response.data.messageId,
      });
    } else {
      console.log("[Email] Brevo not configured. Email logged to console.");
    }
  } catch (error) {
    console.error("[Email] Failed to send owner email:", error);
    throw error;
  }
}

/**
 * Envoyer un email de validation simple
 */
export async function sendValidationEmail(
  clientEmail: string,
  clientName: string,
  quoteNumber: string
): Promise<void> {
  try {
    console.log("[Email] Sending validation email to:", clientEmail);
    console.log("[Email] Quote Number:", quoteNumber);

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #0fb812; color: white; padding: 20px; text-align: center; border-radius: 5px; }
            .content { margin: 20px 0; }
            .section { margin: 15px 0; padding: 15px; background-color: #f5f5f5; border-left: 4px solid #0fb812; }
            .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🚤 Green Boat</h1>
            </div>
            <div class="content">
              <p>Bonjour ${clientName},</p>
              <p>Votre réservation a été enregistrée avec succès.</p>
              <div class="section">
                <h3>Numéro de Devis</h3>
                <p style="font-size: 24px; font-weight: bold; color: #0fb812;">${quoteNumber}</p>
              </div>
              <p>Nous vous confirmerons les détails de votre intervention par email dans les 24 heures.</p>
            </div>
            <div class="footer">
              <p>&copy; 2026 Green Boat</p>
            </div>
          </div>
        </body>
      </html>
    `;

    if (BREVO_API_KEY && BREVO_FROM_EMAIL) {
      const emailPayload = {
        sender: {
          name: "Green Boat",
          email: BREVO_FROM_EMAIL,
        },
        to: [
          {
            email: clientEmail,
            name: clientName,
          },
        ],
        subject: `Confirmation de réservation - ${quoteNumber}`,
        htmlContent,
      };

      const response = await axios.post(
        "https://api.brevo.com/v3/smtp/email",
        emailPayload,
        {
          headers: {
            "api-key": BREVO_API_KEY,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("[Email] Validation email sent successfully via Brevo", {
        messageId: response.data.messageId,
      });
    } else {
      console.log("[Email] Brevo not configured. Email logged to console.");
    }
  } catch (error) {
    console.error("[Email] Failed to send validation email:", error);
    throw error;
  }
}
