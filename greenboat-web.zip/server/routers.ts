import z from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { bookingSchema } from "../shared/schemas";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { generateAvailableTimeSlots } from "./timeSlots";
import Stripe from "stripe";
import { calculateStripeAmount } from "./stripe-products";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  booking: router({
    getAvailableTimeSlots: publicProcedure
      .input(
        z.object({
          date: z.date(),
        })
      )
      .query(async ({ input }) => {
        return await generateAvailableTimeSlots(input.date);
      }),

    create: publicProcedure
      .input(bookingSchema)
      .mutation(async ({ input, ctx }) => {
        const { generateQuoteNumber, calculateTotalPrice } = await import(
          "../shared/utils"
        );

        const quoteNumber = generateQuoteNumber();
        const basePrice = 5000;
        const totalPrice = calculateTotalPrice(
          basePrice,
          Math.round(input.boatLength * 10),
          Math.round(input.surface * 100)
        );

        const reservation = await db.createReservation({
          quoteNumber,
          clientName: input.clientName,
          clientEmail: input.clientEmail,
          clientPhone: input.clientPhone,
          boatName: input.boatName || undefined,
          boatCategory: input.boatCategory,
          boatLength: Math.round(input.boatLength * 10),
          surface: Math.round(input.surface * 100),
          portAddress: input.portAddress,
          quai: input.quai,
          emplacement: input.emplacement,
          zoneId: 1,
          reservationDate: input.reservationDate,
          startTime: input.startTime,
          endTime: input.endTime,
          basePrice,
          totalPrice,
          status: "pending",
          notes: "",
        });

        // Envoyer l'email de confirmation au client
        try {
          const { sendClientEmail } = await import(
            "../server/email"
          );
          await sendClientEmail({
            clientName: input.clientName,
            clientEmail: input.clientEmail,
            clientPhone: input.clientPhone,
            quoteNumber,
            boatName: input.boatName,
            boatCategory: input.boatCategory,
            boatLength: input.boatLength,
            surface: input.surface,
            portAddress: input.portAddress,
            quai: input.quai,
            emplacement: input.emplacement,
            reservationDate: input.reservationDate,
            startTime: input.startTime,
            endTime: input.endTime,
            totalPrice,
          });
        } catch (error) {
          console.error("Failed to send client email:", error);
        }

        // Envoyer l'email de notification au propriétaire
        try {
          const { sendOwnerEmail } = await import(
            "../server/email"
          );
          const ownerEmail = "sent@ik.me"; // Adresse email du propriétaire
          await sendOwnerEmail({
            clientName: input.clientName,
            clientEmail: input.clientEmail,
            clientPhone: input.clientPhone,
            quoteNumber,
            boatName: input.boatName,
            boatCategory: input.boatCategory,
            boatLength: input.boatLength,
            surface: input.surface,
            portAddress: input.portAddress,
            quai: input.quai,
            emplacement: input.emplacement,
            reservationDate: input.reservationDate,
            startTime: input.startTime,
            endTime: input.endTime,
            totalPrice,
          }, ownerEmail);
        } catch (error) {
          console.error("Failed to send owner email:", error);
        }

        try {
          const { notifyOwner } = await import(
            "./_core/notification"
          );
          await notifyOwner({
            title: `Nouvelle réservation: ${quoteNumber}`,
            content: `${input.clientName} a réservé un créneau pour son bateau de ${input.boatLength}m.`,
          });
        } catch (error) {
          console.error("Failed to notify owner:", error);
        }

        return {
          success: true,
          quoteNumber,
          totalPrice,
        };
      }),

    getByQuoteNumber: publicProcedure
      .input(z.object({ quoteNumber: z.string() }))
      .query(async ({ input }) => {
        return await db.getReservationByQuoteNumber(input.quoteNumber);
      }),

    createPaymentSession: publicProcedure
      .input(
        z.object({
          quoteNumber: z.string(),
          totalPrice: z.number(),
          clientEmail: z.string().email(),
          clientName: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          line_items: [
            {
              price_data: {
                currency: "eur",
                product_data: {
                  name: "Nettoyage Écologique de Carène",
                  description: `Réservation: ${input.quoteNumber}`,
                },
                unit_amount: calculateStripeAmount(input.totalPrice),
              },
              quantity: 1,
            },
          ],
          mode: "payment",
          customer_email: input.clientEmail,
          client_reference_id: input.quoteNumber,
          metadata: {
            quote_number: input.quoteNumber,
            client_name: input.clientName,
            client_email: input.clientEmail,
          },
          success_url: `${ctx.req.headers.origin}/booking?success=true&quote=${input.quoteNumber}`,
          cancel_url: `${ctx.req.headers.origin}/booking?canceled=true`,
        });

        return {
          checkoutUrl: session.url,
          sessionId: session.id,
        };
      }),

    list: protectedProcedure
      .input(
        z.object({
          status: z.string().optional(),
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getReservations(input);
      }),


    getBoatBrands: publicProcedure
      .query(async () => {
        try {
          const brands = await db.getAllBoatBrands();
          return {
            success: true,
            data: brands,
          };
        } catch (error) {
          console.error("Error getting boat brands:", error);
          return {
            success: false,
            data: [],
          };
        }
      }),

    getBoatModelsByBrand: publicProcedure
      .input(
        z.object({
          brand: z.string().min(1),
        })
      )
      .query(async ({ input }) => {
        try {
          const models = await db.getBoatModelsByBrand(input.brand);
          return {
            success: true,
            data: models,
          };
        } catch (error) {
          console.error("Error getting boat models:", error);
          return {
            success: false,
            data: [],
          };
        }
      }),

        searchBoatSpecs: publicProcedure
      .input(
        z.object({
          brand: z.string().min(1),
          model: z.string().min(1),
        })
      )
      .query(async ({ input }) => {
        try {
          // Rechercher dans la base de donnees
          const boatModel = await db.searchBoatModel(input.brand, input.model);
          
          if (boatModel) {
            return {
              success: true,
              data: {
                lengthOverall: boatModel.loa,
                lengthAtWaterline: boatModel.loa,
                beam: boatModel.beam,
                draft: boatModel.draft,
                surface: boatModel.surface,
              },
            };
          }
          
          return {
            success: false,
            data: null,
            error: "Bateau non trouve",
          };
        } catch (error) {
          console.error("Error searching boat specs:", error);
          return {
            success: false,
            data: null,
          };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
